extends BodypartPenis

func _init():
	visibleName = "Tapered knotted penis"
	id = "taperedpenisknot"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getCompatibleSpecies():
	return [Species.Any]

func isWinterable() -> bool:
	return true # to use, change npc generation weight func (and/or others) to check if GlobalRegistry.getModule(modid).isDickEnabled(self.id) is true

func isWinteredDefault() -> bool:
	return true # Sets default option for penis

func getLewdAdjective():
	return RNG.pick(["knotted", "avian", "tapered", "smooth"])

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/Bodyparts/Tapered/TaperedKnottedPenis/TaperedKnottedPenis.tscn"

func getTraits():
	return {
		PartTrait.PenisKnot: true,
	}
