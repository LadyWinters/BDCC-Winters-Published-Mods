extends PartSkinBase

func _init():
	id = "caninebarbduallovermark2"
	partID = "caninepenisdualbarb"

func getName():
	return "Lover Mark"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Knotted/Assets/KnottedDualPenis_Lovermark.png"),
	}
