extends PartSkinBase

func _init():
	id = "caninebarbdualscarred"
	partID = "caninepenisdualbarb"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Knotted/Assets/KnottedDualPenis_Scarred.png"),
	}
