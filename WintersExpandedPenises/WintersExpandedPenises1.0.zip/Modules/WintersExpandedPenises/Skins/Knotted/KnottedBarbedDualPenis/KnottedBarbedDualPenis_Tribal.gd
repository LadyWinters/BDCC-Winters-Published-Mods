extends PartSkinBase

func _init():
	id = "caninebarbdualtribal"
	partID = "caninepenisdualbarb"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Knotted/Assets/KnottedDualPenis_Tribal.png"),
	}
