extends PartSkinBase

func _init():
	id = "knottedfluffydualpiercing"
	partID = "knottedfluffydualpenis"

func getName():
	return "Piercing"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Knotted/Assets/KnottedDualPenis_Piercing.png"),
	}
