extends PartSkinBase

func _init():
	id = "knottedfluffydualtribal"
	partID = "knottedfluffydualpenis"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Knotted/Assets/KnottedDualPenis_Tribal.png"),
	}
