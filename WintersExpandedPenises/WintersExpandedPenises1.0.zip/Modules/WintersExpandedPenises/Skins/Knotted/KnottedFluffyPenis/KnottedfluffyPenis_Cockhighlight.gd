extends PartSkinBase

func _init():
	id = "knottedfluffyhighlight"
	partID = "knottedfluffypenis"

func getName():
	return "Highlight"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Knotted/Assets/KnottedPenis_Cockhighlight.png"),
	}
