extends PartSkinBase

func _init():
	id = "knottedfluffypiercing"
	partID = "knottedfluffypenis"

func getName():
	return "Piercing"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Knotted/Assets/KnottedPenis_Piercing.png"),
	}
