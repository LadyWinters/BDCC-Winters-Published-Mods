extends PartSkinBase

func _init():
	id = "knottedfluffylovermark2"
	partID = "knottedfluffypenis"

func getName():
	return "Lover Mark"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Knotted/Assets/KnottedPenis_Lovermark.png"),
	}
