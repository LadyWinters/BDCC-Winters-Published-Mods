extends PartSkinBase

func _init():
	id = "taperedslitgradient"
	partID = "taperedpenisslit"

func getName():
	return "Gradient"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedSlitGradient.png"),
	}
