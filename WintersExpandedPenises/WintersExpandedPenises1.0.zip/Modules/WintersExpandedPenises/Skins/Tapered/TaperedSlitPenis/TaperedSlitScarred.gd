extends PartSkinBase

func _init():
	id = "taperedslitscarred"
	partID = "taperedpenisslit"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedSlitScarred.png"),
	}
	
