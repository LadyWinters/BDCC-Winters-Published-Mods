extends PartSkinBase

func _init():
	id = "taperedlonglovermark2"
	partID = "taperedlongpenis"

func getName():
	return "Lover Mark"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedFluffyLoverMark.png"),
	}
