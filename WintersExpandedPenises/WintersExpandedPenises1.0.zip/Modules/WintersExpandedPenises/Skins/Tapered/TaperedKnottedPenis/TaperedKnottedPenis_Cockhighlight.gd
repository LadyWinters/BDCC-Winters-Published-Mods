extends PartSkinBase

func _init():
	id = "taperedknottedhighlight"
	partID = "taperedpenisknot"

func getName():
	return "Highlight"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedFluffyCockHighlight.png"),
	}
