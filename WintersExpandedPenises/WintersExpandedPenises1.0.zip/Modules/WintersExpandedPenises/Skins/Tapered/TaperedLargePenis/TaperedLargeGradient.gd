extends PartSkinBase

func _init():
	id = "taperedlargegradient"
	partID = "taperedlargepenis"

func getName():
	return "Gradient"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineGradient.png"),
	}
