extends PartSkinBase

func _init():
	id = "barbedfluffydualscarred"
	partID = "barbedfluffydualpenis"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Barbed/Assets/BarbedDualPenis_Scarred.png"),
	}
