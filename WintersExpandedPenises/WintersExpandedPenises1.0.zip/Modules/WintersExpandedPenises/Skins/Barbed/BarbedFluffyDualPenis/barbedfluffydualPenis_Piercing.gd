extends PartSkinBase

func _init():
	id = "barbedfluffydualpiercing"
	partID = "barbedfluffydualpenis"

func getName():
	return "Piercing"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Barbed/Assets/BarbedDualPenis_Piercing.png"),
	}
