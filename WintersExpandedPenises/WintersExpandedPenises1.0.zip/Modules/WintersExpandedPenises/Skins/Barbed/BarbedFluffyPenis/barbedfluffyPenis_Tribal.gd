extends PartSkinBase

func _init():
	id = "barbedfluffytribal"
	partID = "barbedfluffypenis"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Barbed/Assets/BarbedPenis_Tribal.png"),
	}
