extends PartSkinBase

func _init():
	id = "barbedfluffyscarred"
	partID = "barbedfluffypenis"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Barbed/Assets/BarbedPenis_Scarred.png"),
	}
