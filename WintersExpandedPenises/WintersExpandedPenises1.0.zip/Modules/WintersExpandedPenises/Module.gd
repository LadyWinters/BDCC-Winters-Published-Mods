extends Module

var dickOptions : Dictionary = { # DICKtionary :3
	# dick id: option
}

var rodentishere : Reference

func _init():
	id = "WintersExpandedPenises"
	author = "Avery Winters & Selinoccino"
	
	bodyparts = GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedPenises/Bodyparts/")
	
	partSkins = GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedPenises/Skins/")

func register():
	.register()
	
	var modules = GlobalRegistry.getModules().keys()
	if "BallsExtra" in modules: #or true:
		var c : Reference = load("res://Modules/WintersExpandedPenises/codegen.gd").new(id)
		c.do(bodyparts)
	
	if "Hypertus" in modules:
		var c : Reference = load("res://Modules/WintersExpandedPenises/hypercodegen.gd").new(id)
		c.do(bodyparts)
		
		c.doPartSkins(partSkins)
		
	

	var compatd : Dictionary = {
#		"BallsExtra": [ # keep for example
#			GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedPenises/Bodyparts/"), # not loaded
#			GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedPenises/CompatibilityPatches/BallsExtra/"), # loaded
#		]
	}

	for mod in compatd:
		for bp in compatd[mod][int(mod in modules)]:
			GlobalRegistry.registerBodypart(bp)


func isDickEnabled(dick:String) -> bool:
	var option = dickOptions.get(dick)
	if option:
		if rodentishere:
			return rodentishere.getValueForOption(option)
		
		return option.getOptionValue()
	
	return getDefaultForDick(dick)

func getDefaultForDick(dick:String) -> bool:
	var dicko = GlobalRegistry.getBodypartRef(dick)
	if !dicko:
		return false
	return dicko.isWinteredDefault() if dicko.has_method("isWinteredDefault") else false

func RatConfigure(ratconf):
	rodentishere = ratconf
	
	ratconf.overrideModConfigName(id, "Winter's Expanded Penises")
	#ratconfig.getOrCreateModConfig(id).overrideName("Winter's Expanded Penises").overrideAuthor("Avery & Selinoccino")
	
	ratconf.addCategory(id, getCategoryName({}))
	for thing in [PartTrait.PenisBarbs, PartTrait.PenisFlare, PartTrait.PenisKnot, PartTrait.PenisRidges, PartTrait.Ovipositor]:
		ratconf.addCategory(id, getCategoryName({thing:true}))
	
	ratconf.addCategory(id, "Tapered")
	
	var all = GlobalRegistry.getBodypartsIdsBySlot(BodypartSlot.Penis)
	for dickid in all:
		var bp = GlobalRegistry.getBodypartRef(dickid)
		if bp.has_method("isWinterable") && bp.isWinterable():
			var disp : String = "%s (%s)" % [ bp.visibleName if bp else "Error", dickid ]
			var desc : String = "Created by: %s\n\nEnable or disable this dick" % (bp.author if bp && bp.author else "(unknown)")
			
			var cat : String = getCategoryName(bp.getTraits())
			
			var ln : String = bp.visibleName.to_lower()
			if cat != "Hyper":
				if ln.begins_with("tapered"):
					cat = "Tapered"
				elif ln.begins_with("flared"):
					cat = "Flared"
				
			
			
			dickOptions[dickid] = ratconf.addOptionBool(id, dickid, cat, disp, desc, getDefaultForDick(dickid))
	

func getCategoryName(traits) -> String:
	if !traits:
		return "Generic"
	
	if traits.get("Hyperable", false):
		return "Hyper"
	
	match traits.keys()[0]:
		PartTrait.PenisBarbs:
			return "Barbed"
		PartTrait.PenisFlare:
			return "Flared"
		PartTrait.PenisKnot:
			return "Knotted"
		PartTrait.PenisRidges:
			return "Ridged"
		PartTrait.Ovipositor:
			return "Ovipositor"

	return "Generic"

func onFoxLibModInit(foxModuleAPI):
	if dickOptions:
		return
	var all = GlobalRegistry.getBodypartsIdsBySlot(BodypartSlot.Penis)
	for dickid in all:
		var bp = GlobalRegistry.getBodypartRef(dickid)
		if bp.has_method("isWinterable") && bp.isWinterable():
			dickOptions[dickid] = foxModuleAPI.addBooleanOptionInCategory(id, dickid, "%s (%s)" % [ bp.visibleName if bp else "Error", dickid ], "Created by: %s\n\nEnable or disable this dick" % (bp.author if bp && bp.author else "(unknown)"), isDickEnabled(dickid))
	
