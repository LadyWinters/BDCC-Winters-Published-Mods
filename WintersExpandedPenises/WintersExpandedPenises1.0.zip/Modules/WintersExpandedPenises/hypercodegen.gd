extends Reference

var MOD : String = "WintersExpandedPenises"
var compatclass : String = "res://Modules/Z_Hypertus/Misc/ModBodypartPenis.gd"

func _init(mod:String):
	MOD = mod

func doPartSkins(paths:Array) -> void:
	for skinpath in paths:
		var skin = load(skinpath).new()
		if !skin:
			continue
		skin.id += "hyperable"
		skin.partID += "hyperable"
		
		if(!GlobalRegistry.partSkins.has(skin.partID)):
			GlobalRegistry.partSkins[skin.partID] = {}
		GlobalRegistry.partSkins[skin.partID][skin.id] = skin

func do(paths:Array, force:bool=false) -> void:
	for dickpath in paths:
		var dickclass = load(dickpath).new()
		if !dickclass:
			continue
		var dickscript = dickclass.get_script()
#		var path = dickscript.resource_path
		
		var extend = dickscript.source_code.substr(0, dickscript.source_code.find("\n"))
		if !(force or extend.begins_with("extends BodypartPenis")) or extend.strip_edges().ends_with(compatclass):
			continue
		
		var finalSource : String = removeGetTraits(dickscript.source_code)
		finalSource = addGetTraits(finalSource, dickclass.getTraits())
		
		var file : Resource = dickscript.duplicate()
		file.source_code = ("extends \"%s\"" % compatclass) + finalSource.trim_prefix(extend)
#		OS.set_clipboard(file.source_code)
		file.reload()

		var nbpo = file.new()
		nbpo.id = dickclass.id+"hyperable"
		nbpo.visibleName = "Hyper "+nbpo.visibleName.to_lower()
		
		GlobalRegistry.bodyparts[nbpo.id] = nbpo
		GlobalRegistry.bodypartStorageNode.add_child(nbpo)
		
		# register to replace the original
		

func addGetTraits(source:String, traits) -> String:
	var returned : String = "{\"Hyperable\":true}"
	var final : String = source
	
	if traits:
		returned = "{"
		for trait in traits:
			returned += "%s: %s, " % [trait, "true" if traits[trait] else "false"]
		returned += "\"Hyperable\": true"
		
		returned += "}"
	
	var function : String = "\nfunc getTraits():\n\treturn "+returned+"\n"
	
	final += function
	
	return final

func removeGetTraits(source:String) -> String:
	var f : String = source
	
	var idx : int = source.find("func getTraits():")
	var l : int = 0
	if idx == -1:
		return f
	
	var remaining = source.substr(idx)
	
	var lines = Array(remaining.split("\n"))
	if lines:
		l += lines[0].length()
	
	var currentLineIdx : int = 1
	
	while currentLineIdx<lines.size() && lines[currentLineIdx].begins_with("\t"):
		l += lines[currentLineIdx].length() + 2 # 2=newline
		currentLineIdx += 1
	
	l -= 3
	
#	var removed : String = source.substr(idx, l)
#
#	Log.warning("FOUND FUNCTION:\n"+removed+"\nEND")
	
	f.erase(idx, l)
	return f
