extends "res://Modules/WintersExpandedPenises/WinterablePenisTemplate.gd"

func _init():
	visibleName = "Barbed fluffy penis"
	id = "barbedfluffypenis"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getLewdAdjective():
	return RNG.pick(["barbed", "feline-shaped", "feline"])

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/Bodyparts/Barbed/BarbedFluffyPenis/BarbedFluffyPenis.tscn"

func getTraits():
	return {
		PartTrait.PenisBarbs: true,
	}

func getVulgarName() -> String:
	return "barbed feline cock"
