extends Reference

var rod : Module = GlobalRegistry.getModule("RodentUtils")

func onPreDynamicNpcCreation(_npc, _args) -> void:
	if rod.ratmode && RNG.chance(20.0):
		Log.warning("DID FOR %s" % _npc.getName())
		var bp = GlobalRegistry.createBodypart("cursedovipositor")
		var slot = BodypartSlot.Penis
		if !_npc.hasBodypart(slot):
			bp.generateDataFor(_npc)
			_npc.giveBodypart(bp)
			return
		
		var old = _npc.getBodypart(slot).saveData()
		_npc.removeBodypart(slot)
		_npc.giveBodypart(bp)
		bp.loadData(old)
	

func registerToSpecies(sp:Species) -> void:
	for method in ["onPreDynamicNpcCreation"]:
		var cb = sp.createCallable(self, method)
		sp.addCallableToMethod(cb, method)
