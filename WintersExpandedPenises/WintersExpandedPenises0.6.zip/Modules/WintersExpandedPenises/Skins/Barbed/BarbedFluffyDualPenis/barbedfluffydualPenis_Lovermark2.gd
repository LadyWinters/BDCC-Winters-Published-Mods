extends PartSkinBase

func _init():
	id = "barbedfluffyduallovermark2"
	partID = "barbedfluffydualpenis"

func getName():
	return "Lover Mark"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Barbed/Assets/BarbedDualPenis_Lovermark.png"),
	}
