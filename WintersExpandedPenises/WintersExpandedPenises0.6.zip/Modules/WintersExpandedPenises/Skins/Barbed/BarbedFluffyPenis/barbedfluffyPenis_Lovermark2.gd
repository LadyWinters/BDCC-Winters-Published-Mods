extends PartSkinBase

func _init():
	id = "barbedfluffylovermark2"
	partID = "barbedfluffypenis"

func getName():
	return "Lover Mark"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Barbed/Assets/BarbedPenis_Lovermark.png"),
	}
