extends PartSkinBase

func _init():
	id = "taperedlargemottled2"
	partID = "taperedlargepenis"

func getName():
	return "Mottled 2"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineMottled2.png"),
	}
