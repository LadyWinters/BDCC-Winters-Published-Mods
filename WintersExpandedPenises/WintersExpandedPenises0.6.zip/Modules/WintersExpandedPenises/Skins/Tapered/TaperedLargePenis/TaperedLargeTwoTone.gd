extends PartSkinBase

func _init():
	id = "taperedlargetwotone"
	partID = "taperedlargepenis"

func getName():
	return "Two tone"

func getPatternTexture():
	return {
		"": preload("res://Player/Player3D/SkinsParts/Penis/EquinePenis/TwoTone.png"),
	}
