extends PartSkinBase

func _init():
	id = "taperedlargeglow"
	partID = "taperedlargepenis"

func getName():
	return "Glow"

func getPatternTexture():
	return {
		"": load("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineGlow.png"),
		"limp": load("res://Player/Player3D/SkinsParts/Penis/OviPenis/Gradient_limp.png"),
	}
