extends PartSkinBase

func _init():
	id = "taperedknottedpiercing"
	partID = "taperedpenisknot"

func getName():
	return "Piercing"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedFluffyPiercing.png"),
	}
