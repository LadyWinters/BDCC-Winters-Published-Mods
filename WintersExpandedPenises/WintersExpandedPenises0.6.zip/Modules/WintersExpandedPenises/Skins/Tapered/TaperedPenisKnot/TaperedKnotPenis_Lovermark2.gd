extends PartSkinBase

func _init():
	id = "taperedknottedlovermark2"
	partID = "taperedpenisknot"

func getName():
	return "Lover Mark"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedFluffyLoverMark.png"),
	}
