extends PartSkinBase

func _init():
	id = "taperedlonghighlight"
	partID = "taperedlongpenis"

func getName():
	return "Highlight"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedFluffyCockHighlight.png"),
	}
