extends PartSkinBase

func _init():
	id = "taperedlongGradient"
	partID = "taperedlongpenis"

func getName():
	return "Gradient"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedFluffyGradient.png"),
	}
