extends PartSkinBase

func _init():
	id = "taperedlongscarred"
	partID = "taperedlongpenis"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedFluffyScarred.png"),
	}
