extends PartSkinBase

func _init():
	id = "knottedfluffyscarred"
	partID = "knottedfluffypenis"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Knotted/Assets/KnottedPenis_Scarred.png"),
	}
