extends PartSkinBase

func _init():
	id = "caninebarbtribal"
	partID = "caninepenisbarb"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Knotted/Assets/KnottedBarbedPenis_Tribal.png"),
	}
