extends PartSkinBase

func _init():
	id = "caninebarbscarred"
	partID = "caninepenisbarb"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Knotted/Assets/KnottedBarbedPenis_Scarred.png"),
	}
