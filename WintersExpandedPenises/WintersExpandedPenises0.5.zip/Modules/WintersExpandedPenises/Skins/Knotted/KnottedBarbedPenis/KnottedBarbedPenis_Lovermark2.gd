extends PartSkinBase

func _init():
	id = "caninebarblovermark2"
	partID = "caninepenisbarb"

func getName():
	return "Lover Mark"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Knotted/Assets/KnottedBarbedPenis_Lovermark.png"),
	}
