extends PartSkinBase

func _init():
	id = "caninebarbcockhighlight"
	partID = "caninepenisbarb"

func getName():
	return "Highlight"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Knotted/Assets/KnottedBarbedPenis_Cockhighlight.png"),
	}
