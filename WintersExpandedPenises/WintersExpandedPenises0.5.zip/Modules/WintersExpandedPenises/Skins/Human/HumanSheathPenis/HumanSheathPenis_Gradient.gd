extends PartSkinBase

func _init():
	id = "humansheathgradient"
	partID = "humanpenissheath"

func getName():
	return "Gradient"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Human/Assets/HumanSheathPenis_Gradient.png"),
	}
