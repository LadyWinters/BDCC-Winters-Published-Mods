extends PartSkinBase

func _init():
	id = "humanfluffsheathshaftfade"
	partID = "humanpenisfluffsheath"

func getName():
	return "Shaft Fade"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Human/Assets/HumanSheathPenis_Shaft.png"),
	}
