extends PartSkinBase

func _init():
	id = "humansheathshaftfade"
	partID = "humanpenissheath"

func getName():
	return "Shaft Fade"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Human/Assets/HumanSheathPenis_Shaft.png"),
	}
