extends PartSkinBase

func _init():
	id = "humanfluffsheathtiphighlight"
	partID = "humanpenisfluffsheath"

func getName():
	return "Tip Highlight"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Human/Assets/HumanSheathPenis_Tiphighlight.png"),
	}
