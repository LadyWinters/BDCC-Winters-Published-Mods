extends PartSkinBase

func _init():
	id = "equinepierced"
	partID = "equinepenis"

func getName():
	return "Pierced"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquinePierced.png"),
	}
