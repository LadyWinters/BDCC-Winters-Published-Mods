extends PartSkinBase

func _init():
	id = "equinebarbknotmottled1"
	partID = "equinepenisbarbknot"

func getName():
	return "Mottled 1"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineKnottedMottled1.png"),
	}
