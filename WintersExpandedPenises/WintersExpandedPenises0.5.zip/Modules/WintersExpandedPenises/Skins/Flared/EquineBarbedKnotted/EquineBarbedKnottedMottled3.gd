extends PartSkinBase

func _init():
	id = "equinebarbknotmottled3"
	partID = "equinepenisbarbknot"

func getName():
	return "Mottled 3"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineKnottedMottled3.png"),
	}
