extends PartSkinBase

func _init():
	id = "equinebarbknottwotone"
	partID = "equinepenisbarbknot"

func getName():
	return "Two tone"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineKnottedTwoTone.png"),
	}
