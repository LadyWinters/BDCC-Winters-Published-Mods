extends PartSkinBase

func _init():
	id = "equinetaperedmottled2"
	partID = "equinepenistapered"

func getName():
	return "Mottled 2"

func getPatternTexture():
	return {
		"": preload("res://Player/Player3D/SkinsPartsByAuthor/AverageAce/Penis/EquinePenis/EquineMottled2.png"),
	}
