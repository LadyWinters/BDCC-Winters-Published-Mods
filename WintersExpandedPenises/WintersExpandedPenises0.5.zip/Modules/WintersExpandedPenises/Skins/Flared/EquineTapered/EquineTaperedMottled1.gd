extends PartSkinBase

func _init():
	id = "equinetaperedmottled1"
	partID = "equinepenistapered"

func getName():
	return "Mottled 1"

func getPatternTexture():
	return {
		"": preload("res://Player/Player3D/SkinsPartsByAuthor/AverageAce/Penis/EquinePenis/EquineMottled1.png"),
	}
