extends PartSkinBase

func _init():
	id = "equinetaperedmottled3"
	partID = "equinepenistapered"

func getName():
	return "Mottled 3"

func getPatternTexture():
	return {
		"": preload("res://Player/Player3D/SkinsPartsByAuthor/AverageAce/Penis/EquinePenis/EquineMottled3.png"),
	}
