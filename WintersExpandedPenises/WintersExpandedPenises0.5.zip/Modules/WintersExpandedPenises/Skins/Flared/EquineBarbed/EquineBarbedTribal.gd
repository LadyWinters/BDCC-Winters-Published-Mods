extends PartSkinBase

func _init():
	id = "equinebarbtribal"
	partID = "equinepenisbarb"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineTribal.png"),
	}
