extends PartSkinBase

func _init():
	id = "equineknotgradient"
	partID = "equinepenisknot"

func getName():
	return "Gradient"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineKnottedGradient.png"),
	}
