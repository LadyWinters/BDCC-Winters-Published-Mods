extends PartSkinBase

func _init():
	id = "dragonbarbtribal"
	partID = "dragonpenisbarb"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Player/Player3D/SkinsPartsByAuthor/AverageAce/Penis/DragonPenis/DragonTribal.png"),
	}
	
	 
