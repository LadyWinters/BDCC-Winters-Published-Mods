extends PartSkinBase

func _init():
	id = "dragonbarblover"
	partID = "dragonpenisbarb"

func getName():
	return "LoversMark"

func getPatternTexture():
	return {
		"": preload("res://Player/Player3D/SkinsPartsByAuthor/AverageAce/Penis/DragonPenis/DragonLoverMark.png"),
	}

