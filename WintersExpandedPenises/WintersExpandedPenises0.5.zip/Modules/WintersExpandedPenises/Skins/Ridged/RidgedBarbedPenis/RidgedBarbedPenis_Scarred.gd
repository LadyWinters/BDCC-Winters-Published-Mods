extends PartSkinBase

func _init():
	id = "dragonbarbscarred"
	partID = "dragonpenisbarb"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Player/Player3D/SkinsPartsByAuthor/AverageAce/Penis/DragonPenis/DragonScarred.png"),
	}
	
	 
