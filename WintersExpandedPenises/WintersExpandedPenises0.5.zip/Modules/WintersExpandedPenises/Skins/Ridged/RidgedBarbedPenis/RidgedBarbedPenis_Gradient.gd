extends PartSkinBase

func _init():
	id = "dragonbarbgradient"
	partID = "dragonpenisbarb"

func getName():
	return "Gradient"

func getPatternTexture():
	return {
		"": preload("res://Player/Player3D/SkinsPartsByAuthor/AverageAce/Penis/DragonPenis/DragonGradient.png"),
	}
	
