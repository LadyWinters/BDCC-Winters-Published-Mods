extends PartSkinBase

func _init():
	id = "dragonbarbpierced"
	partID = "dragonpenisbarb"

func getName():
	return "Pierced"

func getPatternTexture():
	return {
		"": preload("res://Player/Player3D/SkinsPartsByAuthor/AverageAce/Penis/DragonPenis/Dragonpiercing.png"),
	}
	
	 
