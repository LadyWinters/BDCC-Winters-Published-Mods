extends PartSkinBase

func _init():
	id = "taperedlargepenismottled1"
	partID = "taperedlargepenis"

func getName():
	return "Mottled 1"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedLargePenis_Mottled1Skin.png"),
	}
	
	 
