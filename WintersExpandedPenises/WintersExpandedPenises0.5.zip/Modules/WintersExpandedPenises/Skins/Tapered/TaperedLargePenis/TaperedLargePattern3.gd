extends PartSkinBase

func _init():
	id = "taperedlargepenismottled3"
	partID = "taperedlargepenis"

func getName():
	return "Mottled 3"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedLargePenis_Mottled3Skin.png"),
	}
	
	 
