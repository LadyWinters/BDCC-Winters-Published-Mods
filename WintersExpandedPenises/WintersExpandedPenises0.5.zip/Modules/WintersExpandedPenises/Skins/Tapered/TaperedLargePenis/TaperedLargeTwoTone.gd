extends PartSkinBase

func _init():
	id = "taperedlargepenistwotone"
	partID = "taperedlargepenis"

func getName():
	return "Two tone"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedLargePenis_TwoToneSkin.png"),
	}
	
	 
