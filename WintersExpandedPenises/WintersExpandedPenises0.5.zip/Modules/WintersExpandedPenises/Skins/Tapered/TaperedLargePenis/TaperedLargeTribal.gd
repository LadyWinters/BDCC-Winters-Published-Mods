extends PartSkinBase

func _init():
	id = "taperedlargepenistribal"
	partID = "taperedlargepenis"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedLargePenis_TribalSkin.png"),
	}
	
	 
