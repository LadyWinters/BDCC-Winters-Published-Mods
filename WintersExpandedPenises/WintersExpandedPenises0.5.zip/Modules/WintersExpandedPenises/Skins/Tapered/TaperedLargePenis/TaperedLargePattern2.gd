extends PartSkinBase

func _init():
	id = "taperedlargepenismottled2"
	partID = "taperedlargepenis"

func getName():
	return "Mottled 2"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedLargePenis_Mottled2Skin.png"),
	}
	
	 
