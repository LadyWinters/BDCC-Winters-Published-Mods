extends PartSkinBase

func _init():
	id = "taperedlargepenispierced"
	partID = "taperedlargepenis"

func getName():
	return "Pierced"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedLargePenis_PiercedSkin.png"),
	}
