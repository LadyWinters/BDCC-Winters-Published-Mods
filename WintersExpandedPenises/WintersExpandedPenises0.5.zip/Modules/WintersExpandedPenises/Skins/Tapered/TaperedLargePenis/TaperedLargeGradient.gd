extends PartSkinBase

func _init():
	id = "taperedlargepenisgradient"
	partID = "taperedlargepenis"

func getName():
	return "Gradient"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedLargePenis_GradientSkin.png"),
	}
	
	 
