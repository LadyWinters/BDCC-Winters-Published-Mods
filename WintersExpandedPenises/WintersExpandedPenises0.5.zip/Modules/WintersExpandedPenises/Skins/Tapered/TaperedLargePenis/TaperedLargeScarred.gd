extends PartSkinBase

func _init():
	id = "taperedlargepenisscarred"
	partID = "taperedlargepenis"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedLargePenis_ScarredSkin.png"),
	}
	
	 
