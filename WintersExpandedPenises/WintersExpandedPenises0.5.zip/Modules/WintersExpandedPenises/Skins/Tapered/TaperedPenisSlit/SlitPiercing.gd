extends PartSkinBase

func _init():
	id = "slitpiercing"
	partID = "taperedpenisslit"

func getName():
	return "Pierced"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/TaperedPenisSlit/Assets/SlitPiercing.png"),
	}
	
	 
