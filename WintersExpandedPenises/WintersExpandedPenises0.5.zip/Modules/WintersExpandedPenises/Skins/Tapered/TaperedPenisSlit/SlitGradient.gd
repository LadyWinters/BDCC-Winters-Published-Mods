extends PartSkinBase

func _init():
	id = "slitGradient"
	partID = "taperedpenisslit"

func getName():
	return "Gradient"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/TaperedPenisSlit/Assets/SlitGradient.png"),
	}
