extends PartSkinBase

func _init():
	id = "slitlover"
	partID = "taperedpenisslit"

func getName():
	return "LoversMark"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/TaperedPenisSlit/Assets/SlitLoverMark.png"),
	}

