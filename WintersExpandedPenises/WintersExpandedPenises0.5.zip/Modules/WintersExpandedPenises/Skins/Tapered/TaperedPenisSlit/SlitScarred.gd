extends PartSkinBase

func _init():
	id = "slitscarred"
	partID = "taperedpenisslit"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/TaperedPenisSlit/Assets/SlitScarred.png"),
	}
	
