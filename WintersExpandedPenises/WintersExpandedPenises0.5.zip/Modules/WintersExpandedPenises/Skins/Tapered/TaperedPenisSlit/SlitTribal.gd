extends PartSkinBase

func _init():
	id = "slittribal"
	partID = "taperedpenisslit"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/TaperedPenisSlit/Assets/SlitTribal.png"),
	}
	
	 
