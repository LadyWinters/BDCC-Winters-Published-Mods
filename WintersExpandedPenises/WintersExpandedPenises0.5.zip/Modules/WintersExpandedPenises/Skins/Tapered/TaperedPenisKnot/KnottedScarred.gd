extends PartSkinBase

func _init():
	id = "knottedscarred"
	partID = "taperedpenisknot"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/TaperedPenisKnot/Assets/KnottedScarred.png"),
	}
	
