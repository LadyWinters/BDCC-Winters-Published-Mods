extends PartSkinBase

func _init():
	id = "knottedtribal"
	partID = "taperedpenisknot"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/TaperedPenisKnot/Assets/KnottedTribal.png"),
	}
	
	 
