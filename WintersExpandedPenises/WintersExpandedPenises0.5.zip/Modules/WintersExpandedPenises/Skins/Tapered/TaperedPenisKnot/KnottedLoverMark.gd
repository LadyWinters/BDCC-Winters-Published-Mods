extends PartSkinBase

func _init():
	id = "knottedlover"
	partID = "taperedpenisknot"

func getName():
	return "LoversMark"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/TaperedPenisKnot/Assets/KnottedLoverMark.png"),
	}

