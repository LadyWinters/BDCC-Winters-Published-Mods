extends PartSkinBase

func _init():
	id = "knottedcockhighlight"
	partID = "taperedpenisknot"

func getName():
	return "Highlighted"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/TaperedPenisKnot/Assets/knottedCockHighlight.png"),
	}
