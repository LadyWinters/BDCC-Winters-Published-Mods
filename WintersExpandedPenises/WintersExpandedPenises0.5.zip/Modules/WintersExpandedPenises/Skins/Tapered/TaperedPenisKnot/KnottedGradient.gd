extends PartSkinBase

func _init():
	id = "knottedGradient"
	partID = "taperedpenisknot"

func getName():
	return "Gradient"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/TaperedPenisKnot/Assets/KnottedGradient.png"),
	}
