extends PartSkinBase

func _init():
	id = "knottedpiercing"
	partID = "taperedpenisknot"

func getName():
	return "Pierced"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/TaperedPenisKnot/Assets/KnottedPiercing.png"),
	}
	
	 
