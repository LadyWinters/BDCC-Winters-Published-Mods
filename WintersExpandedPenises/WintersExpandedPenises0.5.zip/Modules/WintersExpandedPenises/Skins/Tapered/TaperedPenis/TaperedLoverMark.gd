extends PartSkinBase

func _init():
	id = "taperedlover"
	partID = "taperedpenis"

func getName():
	return "LoversMark"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedLoverMark.png"),
	}

