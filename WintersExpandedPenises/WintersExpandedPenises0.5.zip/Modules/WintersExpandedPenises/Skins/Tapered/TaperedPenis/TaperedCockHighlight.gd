extends PartSkinBase

func _init():
	id = "taperedcockhighlight"
	partID = "taperedpenis"

func getName():
	return "Highlighted"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedCockHighlight.png"),
	}
