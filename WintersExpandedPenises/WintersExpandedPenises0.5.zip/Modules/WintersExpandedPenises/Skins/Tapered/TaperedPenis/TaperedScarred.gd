extends PartSkinBase

func _init():
	id = "taperedscarred"
	partID = "taperedpenis"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedScarred.png"),
	}
	
