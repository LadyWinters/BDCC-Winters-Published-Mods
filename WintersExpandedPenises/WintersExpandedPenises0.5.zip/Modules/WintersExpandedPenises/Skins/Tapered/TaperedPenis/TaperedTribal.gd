extends PartSkinBase

func _init():
	id = "taperedtribal"
	partID = "taperedpenis"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedTribal.png"),
	}
	
	 
