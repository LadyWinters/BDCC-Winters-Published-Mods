extends PartSkinBase

func _init():
	id = "taperedpiercing"
	partID = "taperedpenis"

func getName():
	return "Pierced"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedPiercing.png"),
	}
	
	 
