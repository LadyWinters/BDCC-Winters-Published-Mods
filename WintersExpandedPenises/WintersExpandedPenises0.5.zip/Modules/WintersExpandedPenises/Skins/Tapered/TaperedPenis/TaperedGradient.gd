extends PartSkinBase

func _init():
	id = "taperedGradient"
	partID = "taperedpenis"

func getName():
	return "Gradient"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Tapered/Assets/TaperedGradient.png"),
	}
