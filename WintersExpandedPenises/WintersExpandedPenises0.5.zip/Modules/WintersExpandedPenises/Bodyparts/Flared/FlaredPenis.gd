extends "res://Player/Bodyparts/Penis/EquinePenis.gd"

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/Bodyparts/Flared/FlaredPenis/FlaredPenis.tscn"

func isWinterable() -> bool:
	return false # to use, change npc generation weight func (and/or others) to check if GlobalRegistry.getModule(modid).isDickEnabled(self.id) is true

func isWinteredDefault() -> bool:
	return true # Sets default option for penis
