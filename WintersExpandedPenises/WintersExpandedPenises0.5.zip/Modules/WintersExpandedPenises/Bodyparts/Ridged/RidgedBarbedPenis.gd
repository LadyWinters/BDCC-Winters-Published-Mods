extends BodypartPenis

func _init():
	visibleName = "Spiney dragon penis"
	id = "dragonpenisbarb"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getCompatibleSpecies():
	return [Species.Any]

func isWinterable() -> bool:
	return true # to use, change npc generation weight func (and/or others) to check if GlobalRegistry.getModule(modid).isDickEnabled(self.id) is true

func isWinteredDefault() -> bool:
	return true # Sets default option for penis

func getLewdAdjective():
	return RNG.pick(["knotted", "spined", "dragon", "barbed", "ridged",])

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/Bodyparts/Ridged/RidgedBarbedPenis/RidgedBarbedPenis.tscn"

func getTraits():
	return {
		PartTrait.PenisKnot: true,
		PartTrait.PenisRidges: true,
		PartTrait.PenisBarbs: true,
	}
