extends BodypartPenis

func _init():
	visibleName = "Fluffy sheathed humanoid penis"
	id = "humanpenisfluffsheath"
	pickedRColor = null
	pickedGColor = null
	pickedBColor = null

func getCompatibleSpecies():
	return [Species.Any]

func isWinterable() -> bool:
	return true # to use, change npc generation weight func (and/or others) to check if GlobalRegistry.getModule(modid).isDickEnabled(self.id) is true

func isWinteredDefault() -> bool:
	return true # Sets default option for penis

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/Bodyparts/Human/HumanSheathPenis/HumanSheathFluffyPenis.tscn"

func getVulgarName() -> String:
	return "cock"

func generateRandomColors(_dynamicCharacter):
	pass
