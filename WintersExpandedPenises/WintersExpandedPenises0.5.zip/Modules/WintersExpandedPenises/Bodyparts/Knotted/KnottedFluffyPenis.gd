extends BodypartPenis

func _init():
	visibleName = "Knotted fluffy penis"
	id = "knottedfluffypenis"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getCompatibleSpecies():
	return [Species.Any]

func isWinterable() -> bool:
	return true # to use, change npc generation weight func (and/or others) to check if GlobalRegistry.getModule(modid).isDickEnabled(self.id) is true

func isWinteredDefault() -> bool:
	return true # Sets default option for penis

func getLewdAdjective():
	return RNG.pick(["knotted", "canine-shaped", "canine"])

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/Bodyparts/Knotted/KnottedFluffyPenis/KnottedFluffyPenis.tscn"

func getTraits():
	return {
		PartTrait.PenisKnot: true,
	}

func getVulgarName() -> String:
	return "knotted canine cock"
