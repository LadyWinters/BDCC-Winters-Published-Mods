extends BodypartPenis

func _init():
	visibleName = "Slitted tapered penis"
	id = "taperedpenisslit"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getCompatibleSpecies():
	return [Species.Any]

func isWinterable() -> bool:
	return true # to use, change npc generation weight func (and/or others) to check if GlobalRegistry.getModule(modid).isDickEnabled(self.id) is true

func isWinteredDefault() -> bool:
	return true # Sets default option for penis

func getLewdAdjective():
	return RNG.pick(["slitted", "tapered", "smooth"])

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/Bodyparts/Tapered/TaperedSlitPenis/TaperedSlitPenis.tscn"

func getCharacterCreatorDesc():
	return "A tapered penis with a genital slit and no balls (visually, the game will still act like you have balls). Also the chastity cage variant is up to your intereptation."
