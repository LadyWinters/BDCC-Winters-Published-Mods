extends BodypartPenis

func _init():
	visibleName = "Barbed fluffy penis"
	id = "barbedfluffypenis"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getCompatibleSpecies():
	return [Species.Any]

func isWinterable() -> bool:
	return true # to use, change npc generation weight func (and/or others) to check if GlobalRegistry.getModule(modid).isDickEnabled(self.id) is true

func isWinteredDefault() -> bool:
	return true # Sets default option for penis

func getLewdAdjective():
	return RNG.pick(["barbed", "feline-shaped", "feline"])

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/Bodyparts/Barbed/BarbedFluffyPenis/BarbedFluffyPenis.tscn"

func getTraits():
	return {
		PartTrait.PenisBarbs: true,
	}

func getVulgarName() -> String:
	return "barbed feline cock"
