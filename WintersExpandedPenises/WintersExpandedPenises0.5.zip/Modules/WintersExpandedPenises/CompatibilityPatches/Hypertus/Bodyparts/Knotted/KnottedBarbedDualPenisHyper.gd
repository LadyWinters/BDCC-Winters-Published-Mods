extends "res://Modules/Z_Hypertus/Misc/ModBodypartPenis.gd"

func _init():
	visibleName = "Hyperable knotted barbed dual penis"
	id = "caninepenisdualbarbhyperable"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getCharacterCreatorDesc():
	return "Required to experience the Hypertus mod"

func getCompatibleSpecies():
	return [Species.Any]

func isWinterable() -> bool:
	return true # to use, change npc generation weight func (and/or others) to check if GlobalRegistry.getModule(modid).isDickEnabled(self.id) is true

func isWinteredDefault() -> bool:
	return false # Sets default option for penis

func getLewdAdjective():
	return RNG.pick(["knotted", "canine-shaped", "canine", "barbed",])

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/Bodyparts/Knotted/KnottedBarbedPenis/KnottedBarbedDualPenis.tscn"
	
func getTraits():
	return {
		PartTrait.PenisKnot: true,
		PartTrait.PenisBarbs: true,
		"Hyperable": true,
	}

func getVulgarName() -> String:
	return "knotted and barbed hybrid cock"
