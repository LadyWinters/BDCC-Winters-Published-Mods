extends "res://Modules/Z_Hypertus/Misc/ModBodypartPenis.gd"

func _init():
	visibleName = "Hyperable knotted fluffy penis"
	id = "knottedfluffypenishyperable"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getCharacterCreatorDesc():
	return "Required to experience the Hypertus mod"

func getCompatibleSpecies():
	return [Species.Any]

func isWinterable() -> bool:
	return true # to use, change npc generation weight func (and/or others) to check if GlobalRegistry.getModule(modid).isDickEnabled(self.id) is true

func isWinteredDefault() -> bool:
	return true # Sets default option for penis

func getLewdAdjective():
	return RNG.pick(["knotted", "canine-shaped", "canine"])

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/Bodyparts/Knotted/KnottedFluffyPenis/KnottedFluffyPenis.tscn"

func getTraits():
	return {
		PartTrait.PenisKnot: true,
		"Hyperable": true,
	}

func getVulgarName() -> String:
	return "knotted canine cock"
