extends "res://Modules/Z_Hypertus/Misc/ModBodypartPenis.gd"

func _init():
	visibleName = "Hyperable fluffy sheathed humanoid penis"
	id = "humanpenisfluffsheathhyperable"
	pickedRColor = null
	pickedGColor = null
	pickedBColor = null

func getCharacterCreatorDesc():
	return "Required to experience the Hypertus mod"

func getCompatibleSpecies():
	return [Species.Any]

func isWinterable() -> bool:
	return true # to use, change npc generation weight func (and/or others) to check if GlobalRegistry.getModule(modid).isDickEnabled(self.id) is true

func isWinteredDefault() -> bool:
	return true # Sets default option for penis

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/Bodyparts/Human/HumanSheathPenis/HumanSheathFluffyPenis.tscn"

func getTraits():
	return {
		"Hyperable": true,
	}

func getVulgarName() -> String:
	return "cock"

func generateRandomColors(_dynamicCharacter):
	pass
