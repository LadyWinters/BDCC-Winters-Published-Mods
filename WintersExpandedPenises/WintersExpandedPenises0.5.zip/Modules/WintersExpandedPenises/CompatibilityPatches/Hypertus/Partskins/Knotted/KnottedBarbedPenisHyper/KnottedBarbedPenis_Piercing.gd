extends PartSkinBase

func _init():
	id = "caninebarbpiercinghyperable"
	partID = "caninepenisbarbhyperable"

func getName():
	return "Piercing"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Knotted/Assets/KnottedBarbedPenis_Piercing.png"),
	}
