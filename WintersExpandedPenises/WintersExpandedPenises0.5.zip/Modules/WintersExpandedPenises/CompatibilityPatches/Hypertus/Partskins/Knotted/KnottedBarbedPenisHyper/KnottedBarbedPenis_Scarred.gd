extends PartSkinBase

func _init():
	id = "caninebarbscarredhyperable"
	partID = "caninepenisbarbhyperable"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Knotted/Assets/KnottedBarbedPenis_Scarred.png"),
	}
