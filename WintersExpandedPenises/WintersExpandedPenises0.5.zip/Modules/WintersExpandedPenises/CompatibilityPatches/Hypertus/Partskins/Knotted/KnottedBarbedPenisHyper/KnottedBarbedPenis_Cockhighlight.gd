extends PartSkinBase

func _init():
	id = "caninebarbcockhighlighthyperable"
	partID = "caninepenisbarbhyperable"

func getName():
	return "Highlight"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Knotted/Assets/KnottedBarbedPenis_Cockhighlight.png"),
	}
