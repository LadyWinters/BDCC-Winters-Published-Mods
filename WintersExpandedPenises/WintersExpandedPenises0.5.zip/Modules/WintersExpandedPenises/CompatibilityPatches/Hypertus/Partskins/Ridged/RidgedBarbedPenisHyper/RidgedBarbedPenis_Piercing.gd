extends PartSkinBase

func _init():
	id = "dragonbarbpiercedhyperable"
	partID = "dragonpenisbarbhyperable"

func getName():
	return "Pierced"

func getPatternTexture():
	return {
		"": preload("res://Player/Player3D/SkinsPartsByAuthor/AverageAce/Penis/DragonPenis/Dragonpiercing.png"),
	}
	
	 
