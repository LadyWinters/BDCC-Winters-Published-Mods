extends PartSkinBase

func _init():
	id = "dragonbarbscarredhyperable"
	partID = "dragonpenisbarbhyperable"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Player/Player3D/SkinsPartsByAuthor/AverageAce/Penis/DragonPenis/DragonScarred.png"),
	}
	
	 
