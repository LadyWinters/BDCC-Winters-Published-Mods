extends PartSkinBase

func _init():
	id = "dragonbarbgradienthyperable"
	partID = "dragonpenisbarbhyperable"

func getName():
	return "Gradient"

func getPatternTexture():
	return {
		"": preload("res://Player/Player3D/SkinsPartsByAuthor/AverageAce/Penis/DragonPenis/DragonGradient.png"),
	}
