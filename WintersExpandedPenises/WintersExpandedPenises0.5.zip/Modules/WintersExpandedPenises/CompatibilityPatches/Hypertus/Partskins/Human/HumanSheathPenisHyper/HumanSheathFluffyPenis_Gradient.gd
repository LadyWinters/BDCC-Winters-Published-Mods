extends PartSkinBase

func _init():
	id = "humanfluffsheathgradienthyperable"
	partID = "humanpenisfluffsheathhyperable"

func getName():
	return "Gradient"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Human/Assets/HumanSheathPenis_Gradient.png"),
	}
