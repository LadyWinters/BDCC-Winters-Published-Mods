extends PartSkinBase

func _init():
	id = "humanfluffsheathtiphighlighthyperable"
	partID = "humanpenisfluffsheathhyperable"

func getName():
	return "Tip Highlight"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Human/Assets/HumanSheathPenis_Tiphighlight.png"),
	}
