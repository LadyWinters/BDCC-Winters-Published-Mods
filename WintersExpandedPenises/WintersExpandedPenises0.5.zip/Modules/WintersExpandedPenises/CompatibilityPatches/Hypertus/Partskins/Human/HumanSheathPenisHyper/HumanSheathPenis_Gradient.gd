extends PartSkinBase

func _init():
	id = "humansheathgradienthyperable"
	partID = "humanpenissheathhyperable"

func getName():
	return "Gradient"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Human/Assets/HumanSheathPenis_Gradient.png"),
	}
