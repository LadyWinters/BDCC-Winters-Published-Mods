extends PartSkinBase

func _init():
	id = "humanfluffsheathshaftfadehyperable"
	partID = "humanpenisfluffsheathhyperable"

func getName():
	return "Shaft Fade"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Human/Assets/HumanSheathPenis_Shaft.png"),
	}
