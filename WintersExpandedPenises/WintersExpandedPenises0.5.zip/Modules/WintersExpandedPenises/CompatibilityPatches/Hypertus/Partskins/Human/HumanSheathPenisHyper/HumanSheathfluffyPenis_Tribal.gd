extends PartSkinBase

func _init():
	id = "humanfluffsheathtribalhyperable"
	partID = "humanpenisfluffsheathhyperable"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Human/Assets/HumanSheathPenis_Tribal.png"),
	}
