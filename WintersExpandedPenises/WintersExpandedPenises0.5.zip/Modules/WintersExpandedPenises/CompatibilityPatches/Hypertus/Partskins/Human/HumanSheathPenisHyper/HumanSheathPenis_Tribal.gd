extends PartSkinBase

func _init():
	id = "humansheathtribalhyperable"
	partID = "humanpenissheathhyperable"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Human/Assets/HumanSheathPenis_Tribal.png"),
	}
