extends PartSkinBase

func _init():
	id = "humansheathtiphighlighthyperable"
	partID = "humanpenissheathhyperable"

func getName():
	return "Tip Highlight"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Human/Assets/HumanSheathPenis_Tiphighlight.png"),
	}
