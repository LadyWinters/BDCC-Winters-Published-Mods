extends PartSkinBase

func _init():
	id = "equineknotmottled3hyperable"
	partID = "equinepenisknothyperable"

func getName():
	return "Mottled 3"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineKnottedMottled3.png"),
	}
