extends PartSkinBase

func _init():
	id = "equineknotglowhyperable"
	partID = "equinepenisknothyperable"

func getName():
	return "Glow"

func getPatternTexture():
	return {
		"": load("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineKnottedGlow.png"),
		"limp": load("res://Player/Player3D/SkinsParts/Penis/OviPenis/Gradient_limp.png"),
	}
