extends PartSkinBase

func _init():
	id = "equinetaperedscarredhyperable"
	partID = "equinepenistaperedhyperable"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineScarred.png"),
	}
