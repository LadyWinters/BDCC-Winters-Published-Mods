extends PartSkinBase

func _init():
	id = "equinebarbknottribalhyperable"
	partID = "equinepenisbarbknothyperable"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineKnottedTribal.png"),
	}
