extends PartSkinBase

func _init():
	id = "equineknotmottled2hyperable"
	partID = "equinepenisknothyperable"

func getName():
	return "Mottled 2"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineKnottedMottled2.png"),
	}
