extends PartSkinBase

func _init():
	id = "equinebarbpiercedhyperable"
	partID = "equinepenisbarbhyperable"

func getName():
	return "Pierced"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquinePierced.png"),
	}
