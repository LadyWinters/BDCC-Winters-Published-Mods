extends PartSkinBase

func _init():
	id = "equinetaperedpiercedhyperable"
	partID = "equinepenistaperedhyperable"

func getName():
	return "Pierced"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquinePierced.png"),
	}
