extends PartSkinBase

func _init():
	id = "equinebarbtribalhyperable"
	partID = "equinepenisbarbhyperable"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineTribal.png"),
	}
