extends PartSkinBase

func _init():
	id = "equinebarbknotglowhyperable"
	partID = "equinepenisbarbknothyperable"

func getName():
	return "Glow"

func getPatternTexture():
	return {
		"": load("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineKnottedGlow.png"),
		"limp": load("res://Player/Player3D/SkinsParts/Penis/OviPenis/Gradient_limp.png"),
	}
