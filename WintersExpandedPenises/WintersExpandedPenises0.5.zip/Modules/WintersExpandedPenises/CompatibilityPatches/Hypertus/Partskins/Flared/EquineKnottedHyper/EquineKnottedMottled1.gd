extends PartSkinBase

func _init():
	id = "equineknotmottled1hyperable"
	partID = "equinepenisknothyperable"

func getName():
	return "Mottled 1"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineKnottedMottled1.png"),
	}
