extends PartSkinBase

func _init():
	id = "equinebarbknotscarredhyperable"
	partID = "equinepenisbarbknothyperable"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineKnottedScarred.png"),
	}
