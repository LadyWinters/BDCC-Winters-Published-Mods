extends PartSkinBase

func _init():
	id = "equineknothighlighthyperable"
	partID = "equinepenisknothyperable"

func getName():
	return "Ball Highlight"

func getPatternTexture():
	return {
		"": load("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineKnottedBallHighlight.png"),
		"limp": load("res://Player/Player3D/SkinsPartsByAuthor/AverageAce/Penis/EquinePenis/EquineBalls_limp.png"),
	}
	
	 
