extends PartSkinBase

func _init():
	id = "equineknotgradienthyperable"
	partID = "equinepenisknothyperable"

func getName():
	return "Gradient"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineKnottedGradient.png"),
	}
