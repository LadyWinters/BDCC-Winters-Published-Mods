extends PartSkinBase

func _init():
	id = "equinepiercedhyperable"
	partID = "equinepenishyperable"

func getName():
	return "Pierced"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquinePierced.png"),
	}
