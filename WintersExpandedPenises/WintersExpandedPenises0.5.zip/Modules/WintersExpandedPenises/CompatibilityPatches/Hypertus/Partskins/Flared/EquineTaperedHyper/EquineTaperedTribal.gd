extends PartSkinBase

func _init():
	id = "equinetaperedtribalhyperable"
	partID = "equinepenistaperedhyperable"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineTribal.png"),
	}
