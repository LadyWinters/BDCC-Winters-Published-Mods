extends PartSkinBase

func _init():
	id = "equinebarbknottwotonehyperable"
	partID = "equinepenisbarbknothyperable"

func getName():
	return "Two tone"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineKnottedTwoTone.png"),
	}
