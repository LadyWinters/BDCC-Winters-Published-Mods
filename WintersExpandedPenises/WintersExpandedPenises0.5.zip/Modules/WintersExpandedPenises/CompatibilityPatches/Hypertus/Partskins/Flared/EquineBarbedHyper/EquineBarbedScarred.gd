extends PartSkinBase

func _init():
	id = "equinebarbscarredhyperable"
	partID = "equinepenisbarbhyperable"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersExpandedPenises/Skins/Flared/Assets/EquineScarred.png"),
	}
