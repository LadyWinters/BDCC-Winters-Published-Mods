# Balls Extra Compat Information
All compat files are now generated automatically via code gen and do not need be done manually.
