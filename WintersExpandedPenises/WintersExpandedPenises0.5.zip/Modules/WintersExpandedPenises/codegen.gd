extends Reference

var MOD : String = "WintersExpandedPenises"
var compatclass : String = "res://Modules/BallsExtraModule/Base/BodypartBetterPenis.gd"

func _init(mod:String):
	MOD = mod

func do(paths:Array, force:bool=false) -> void:
	for dickpath in paths:
		var dickclass = load(dickpath).new()
		if !dickclass:
			continue
		var dickscript = dickclass.get_script()
#		var path = dickscript.resource_path
		
		var extend = dickscript.source_code.substr(0, dickscript.source_code.find("\n"))
		if !(force or extend.begins_with("extends BodypartPenis")) or extend.strip_edges().ends_with(compatclass):
			continue
		
		var file : Resource = dickscript.duplicate()
		file.source_code = ("extends \"%s\"" % compatclass) + dickscript.source_code.trim_prefix(extend)
		file.reload()
		
		var nbpo = file.new()
		GlobalRegistry.bodyparts[dickclass.id].free()
		GlobalRegistry.bodyparts[dickclass.id] = nbpo
		GlobalRegistry.bodypartStorageNode.add_child(nbpo)
		
		# register to replace the original
		
