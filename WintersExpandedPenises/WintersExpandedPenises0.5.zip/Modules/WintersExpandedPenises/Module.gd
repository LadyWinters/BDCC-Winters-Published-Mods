extends Module

var dickOptions : Dictionary = { # DICKtionary :3
	# dick id: option
}

func _init():
	id = "WintersExpandedPenises"
	author = "Avery Winters (Code Improvements: Selinoccino)"

	partSkins = GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedPenises/Skins/")

func register():
	bodyparts = GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedPenises/Bodyparts/")
	.register()
	
	var modules = GlobalRegistry.getModules().keys()
	if "BallsExtra" in modules: #or true:
		var c : Reference = load("res://Modules/WintersExpandedPenises/codegen.gd").new(id)
		c.do(bodyparts)
		
	

	var compatd : Dictionary = {
#		"BallsExtra": [ # keep for example
#			GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedPenises/Bodyparts/"), # not loaded
#			GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedPenises/CompatibilityPatches/BallsExtra/"), # loaded
#		]
	}

	for mod in compatd:
		for bp in compatd[mod][int(mod in modules)]:
			GlobalRegistry.registerBodypart(bp)


func isDickEnabled(dick:String) -> bool:
	var option = dickOptions.get(dick)
	if option:
		return option.getOptionValue()
	
	return getDefaultForDick(dick)

func getDefaultForDick(dick:String) -> bool:
	var dicko = GlobalRegistry.getBodypartRef(dick)
	if !dicko:
		return false
	return dicko.isWinteredDefault() if dicko.has_method("isWinteredDefault") else false

func onFoxLibModInit(foxModuleAPI):
	var all = GlobalRegistry.getBodypartsIdsBySlot(BodypartSlot.Penis)
	for dickid in all:
		var bp = GlobalRegistry.getBodypartRef(dickid)
		if bp.has_method("isWinterable") && bp.isWinterable():
			dickOptions[dickid] = foxModuleAPI.addBooleanOptionInCategory(id, dickid, "%s (%s)" % [ bp.visibleName if bp else "Error", dickid ], "Created by: %s\n\nEnable or disable this dick" % (bp.author if bp && bp.author else "(unknown)"), isDickEnabled(dickid))
	

