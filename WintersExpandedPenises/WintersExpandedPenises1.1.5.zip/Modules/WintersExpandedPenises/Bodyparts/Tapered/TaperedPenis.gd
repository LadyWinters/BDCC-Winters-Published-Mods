extends "res://Modules/WintersExpandedPenises/WinterablePenisTemplate.gd"

func _init():
	visibleName = "Tapered penis"
	id = "taperedpenis"
	pickedGColor = Color.red
	pickedBColor = Color.darkred

func getLewdAdjective():
	return RNG.pick(["smooth", "tapered"])

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/Bodyparts/Tapered/TaperedPenis/TaperedPenis.tscn"
