extends "res://Modules/WintersExpandedPenises/WinterablePenisTemplate.gd"

func _init():
	visibleName = "Sheathed humanoid penis"
	id = "humanpenissheath"
	pickedRColor = null
	pickedGColor = null
	pickedBColor = null

func isWinteredDefault() -> bool:
	return false # Sets default option for penis

func getDoll3DScene():
	return "res://Modules/WintersExpandedPenises/Bodyparts/Human/HumanSheathPenis/HumanSheathPenis.tscn"

func getVulgarName() -> String:
	return "cock"

func generateRandomColors(_dynamicCharacter):
	pass
