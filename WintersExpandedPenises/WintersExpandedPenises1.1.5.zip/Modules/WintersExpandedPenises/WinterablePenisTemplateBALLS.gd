extends "res://Modules/BallsExtraModule/Base/BodypartBetterPenis.gd"

func getCompatibleSpecies():
	if GlobalRegistry.getModule("WintersExpandedPenises").isDickEnabled(self.id):
		return [Species.Any]
	return []

func isWinterable() -> bool:
	return true # to use, change npc generation weight func (and/or others) to check if GlobalRegistry.getModule(modid).isDickEnabled(self.id) is true

func isWinteredDefault() -> bool:
	return true # Sets default option for penis

func getCharacterCreatorDesc():
	return "WintersExpandedPenises"

func getTraits():
	return {}
