extends PartSkinBase

func _init():
	id = "equinebarbtribal"
	partID = "equinepenisbarb"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisBarb/Skins/EquineBarbTribal.png"),
	}
	
	 
