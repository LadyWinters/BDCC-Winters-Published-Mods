extends PartSkinBase

func _init():
	id = "equinebarbscarred"
	partID = "equinepenisbarb"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisBarb/Skins/EquineBarbScarred.png"),
	}
	
	 
