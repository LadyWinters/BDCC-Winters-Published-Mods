extends PartSkinBase

func _init():
	id = "equinebarbmottled3"
	partID = "equinepenisbarb"

func getName():
	return "Mottled 3"

func getPatternTexture():
	return {
		"": preload("res://Player/Player3D/SkinsPartsByAuthor/AverageAce/Penis/EquinePenis/EquineMottled3.png"),
	}
	
	 
