extends PartSkinBase

func _init():
	id = "equinebarbpierced"
	partID = "equinepenisbarb"

func getName():
	return "Pierced"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisBarb/Skins/EquineBarbPierced.png"),
	}
	
	 
