extends PartSkinBase

func _init():
	id = "equinebarbknotgradient"
	partID = "equinepenisbarbknot"

func getName():
	return "Gradient"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisBarbKnot/Skins/EquineBarbKnotGradient.png"),
	}
	
	 
