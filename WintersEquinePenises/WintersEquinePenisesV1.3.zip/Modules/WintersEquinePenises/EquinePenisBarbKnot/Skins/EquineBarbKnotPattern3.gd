extends PartSkinBase

func _init():
	id = "equinebarbknotmottled3"
	partID = "equinepenisbarbknot"

func getName():
	return "Mottled 3"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisBarbKnot/Skins/EquineBarbKnotPattern3.png"),
	}
	
	 
