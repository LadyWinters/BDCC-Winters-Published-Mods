extends PartSkinBase

func _init():
	id = "equinebarbknotscarred"
	partID = "equinepenisbarbknot"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisBarbKnot/Skins/EquineBarbKnotScarred.png"),
	}
	
	 
