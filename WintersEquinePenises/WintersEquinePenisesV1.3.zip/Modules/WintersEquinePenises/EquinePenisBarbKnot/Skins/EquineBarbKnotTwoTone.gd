extends PartSkinBase

func _init():
	id = "equinebarbknottwotone"
	partID = "equinepenisbarbknot"

func getName():
	return "Two tone"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisBarbKnot/Skins/EquineBarbKnotTwoTone.png"),
	}
	
	 
