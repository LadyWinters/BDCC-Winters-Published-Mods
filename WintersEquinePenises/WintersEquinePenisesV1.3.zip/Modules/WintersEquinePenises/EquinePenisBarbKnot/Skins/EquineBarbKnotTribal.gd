extends PartSkinBase

func _init():
	id = "equinebarbknottribal"
	partID = "equinepenisbarbknot"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisBarbKnot/Skins/EquineBarbKnotTribal.png"),
	}
	
	 
