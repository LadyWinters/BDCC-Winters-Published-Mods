extends PartSkinBase

func _init():
	id = "equinebarbknotpiercedhyperable"
	partID = "equinepenisbarbknothyperable"

func getName():
	return "Pierced"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisBarbKnot/Skins/EquineBarbKnotPierced.png"),
	}
