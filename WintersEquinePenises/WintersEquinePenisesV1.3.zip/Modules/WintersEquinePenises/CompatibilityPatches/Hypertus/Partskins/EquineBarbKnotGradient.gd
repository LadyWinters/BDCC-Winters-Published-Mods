extends PartSkinBase

func _init():
	id = "equinebarbknotgradienthyperable"
	partID = "equinepenisbarbknothyperable"

func getName():
	return "Gradient"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisBarbKnot/Skins/EquineBarbKnotGradient.png"),
	}
	
	 
