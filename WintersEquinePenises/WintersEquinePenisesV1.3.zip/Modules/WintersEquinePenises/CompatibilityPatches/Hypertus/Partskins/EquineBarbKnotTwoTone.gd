extends PartSkinBase

func _init():
	id = "equinebarbknottwotonehyperable"
	partID = "equinepenisbarbknothyperable"

func getName():
	return "Two tone"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisBarbKnot/Skins/EquineBarbKnotTwoTone.png"),
	}
	
	 
