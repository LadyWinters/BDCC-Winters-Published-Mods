extends PartSkinBase

func _init():
	id = "equinebarbknotmottled1hyperable"
	partID = "equinepenisbarbknothyperable"

func getName():
	return "Mottled 1"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisBarbKnot/Skins/EquineBarbKnotPattern1.png"),
	}
	
	 
