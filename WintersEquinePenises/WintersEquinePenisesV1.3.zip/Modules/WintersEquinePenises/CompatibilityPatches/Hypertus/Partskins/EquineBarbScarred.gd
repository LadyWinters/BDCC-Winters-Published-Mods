extends PartSkinBase

func _init():
	id = "equinebarbscarredhyperable"
	partID = "equinepenisbarbhyperable"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisBarb/Skins/EquineBarbScarred.png"),
	}
	
	 
