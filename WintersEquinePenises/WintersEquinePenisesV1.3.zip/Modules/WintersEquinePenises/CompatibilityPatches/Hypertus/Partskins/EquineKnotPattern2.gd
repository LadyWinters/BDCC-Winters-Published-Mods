extends PartSkinBase

func _init():
	id = "equineknotmottled2hyperable"
	partID = "equinepenisknothyperable"

func getName():
	return "Mottled 2"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisKnot/Skins/EquineKnotPattern2.png"),
	}
	
	 
