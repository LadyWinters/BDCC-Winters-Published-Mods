extends PartSkinBase

func _init():
	id = "equineknotmottled1hyperable"
	partID = "equinepenisknothyperable"

func getName():
	return "Mottled 1"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisKnot/Skins/EquineKnotPattern1.png"),
	}
	
	 
