extends Module

#This assigns true or false depending on wether Balls Extra is loaded so we can refer to it when loading bodyparts below.
var BallsExtraLoad = ResourceLoader.exists("res://Modules/BallsExtraModule/Base/BodypartBetterPenis.gd")

func _init():
	id = "WintersEquinePenisPenises"
	author = "Avery Winters"

	#If the Balls Extra mod is loaded this should load the compatible .gd files to extend the modified penis bodypart allowing ball density changes
	if (BallsExtraLoad == true):
		bodyparts = [
			#Start Equine Balls Extra Files
			"res://Modules/WintersEquinePenises/CompatibilityPatches/BallsExtra/EquinePenisBarbBE.gd",
			"res://Modules/WintersEquinePenises/CompatibilityPatches/BallsExtra/EquinePenisBarbKnotBE.gd",
			"res://Modules/WintersEquinePenises/CompatibilityPatches/BallsExtra/EquinePenisKnotBE.gd",
			"res://Modules/WintersEquinePenises/CompatibilityPatches/BallsExtra/EquinePenisTaperedBE.gd",
			]

	elif (BallsExtraLoad == false):
		bodyparts = [
			#Start Equine Barbed Files
			"res://Modules/WintersEquinePenises/EquinePenisBarb/EquinePenisBarb.gd",
			#Start Equine Barbed & Knotted Files
			"res://Modules/WintersEquinePenises/EquinePenisBarbKnot/EquinePenisBarbKnot.gd",
			#Start Equine Knotted Files
			"res://Modules/WintersEquinePenises/EquinePenisKnot/EquinePenisKnot.gd",
			#Start Equine Tapered Files
			"res://Modules/WintersEquinePenises/EquinePenisTapered/EquinePenisTapered.gd",
			]

	partSkins = [
		#Start Equine Barbed Files
		"res://Modules/WintersEquinePenises/EquinePenisBarb/Skins/EquineBarbGradient.gd",
		"res://Modules/WintersEquinePenises/EquinePenisBarb/Skins/EquineBarbPattern1.gd",
		"res://Modules/WintersEquinePenises/EquinePenisBarb/Skins/EquineBarbPattern2.gd",
		"res://Modules/WintersEquinePenises/EquinePenisBarb/Skins/EquineBarbPattern3.gd",
		"res://Modules/WintersEquinePenises/EquinePenisBarb/Skins/EquineBarbScarred.gd",
		"res://Modules/WintersEquinePenises/EquinePenisBarb/Skins/EquineBarbTribal.gd",
		"res://Modules/WintersEquinePenises/EquinePenisBarb/Skins/EquineBarbPierced.gd",
		"res://Modules/WintersEquinePenises/EquinePenisBarb/Skins/EquineBarbTwoTone.gd",
		#Start Equine Barbed & Knotted Files
		"res://Modules/WintersEquinePenises/EquinePenisBarbKnot/Skins/EquineBarbKnotGradient.gd",
		"res://Modules/WintersEquinePenises/EquinePenisBarbKnot/Skins/EquineBarbKnotPattern1.gd",
		"res://Modules/WintersEquinePenises/EquinePenisBarbKnot/Skins/EquineBarbKnotPattern2.gd",
		"res://Modules/WintersEquinePenises/EquinePenisBarbKnot/Skins/EquineBarbKnotPattern3.gd",
		"res://Modules/WintersEquinePenises/EquinePenisBarbKnot/Skins/EquineBarbKnotScarred.gd",
		"res://Modules/WintersEquinePenises/EquinePenisBarbKnot/Skins/EquineBarbKnotTribal.gd",
		"res://Modules/WintersEquinePenises/EquinePenisBarbKnot/Skins/EquineBarbKnotPierced.gd",
		"res://Modules/WintersEquinePenises/EquinePenisBarbKnot/Skins/EquineBarbKnotTwoTone.gd",
		#Start Equine Knotted Files
		"res://Modules/WintersEquinePenises/EquinePenisKnot/Skins/EquineKnotGradient.gd",
		"res://Modules/WintersEquinePenises/EquinePenisKnot/Skins/EquineKnotPattern1.gd",
		"res://Modules/WintersEquinePenises/EquinePenisKnot/Skins/EquineKnotPattern2.gd",
		"res://Modules/WintersEquinePenises/EquinePenisKnot/Skins/EquineKnotPattern3.gd",
		"res://Modules/WintersEquinePenises/EquinePenisKnot/Skins/EquineKnotScarred.gd",
		"res://Modules/WintersEquinePenises/EquinePenisKnot/Skins/EquineKnotTribal.gd",
		"res://Modules/WintersEquinePenises/EquinePenisKnot/Skins/EquineKnotTwoTone.gd",
		#Start Equine Tapered Files
		"res://Modules/WintersEquinePenises/EquinePenisTapered/Skins/DeerPattern1.gd",
		"res://Modules/WintersEquinePenises/EquinePenisTapered/Skins/DeerPattern2.gd",
		"res://Modules/WintersEquinePenises/EquinePenisTapered/Skins/DeerPattern3.gd",
		"res://Modules/WintersEquinePenises/EquinePenisTapered/Skins/DeerTwoTone.gd",
	]
