extends PartSkinBase

func _init():
	id = "equineknotscarred"
	partID = "equinepenisknot"

func getName():
	return "Scarred"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisKnot/Skins/EquineKnotScarred.png"),
	}
	
	 
