extends PartSkinBase

func _init():
	id = "equineknottribal"
	partID = "equinepenisknot"

func getName():
	return "Tribal"

func getPatternTexture():
	return {
		"": preload("res://Modules/WintersEquinePenises/EquinePenisKnot/Skins/EquineKnotTribal.png"),
	}
	
	 
