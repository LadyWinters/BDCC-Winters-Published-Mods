extends "res://Modules/WintersCoreModule/BodypartTemplates/TemplateBreastsScaleable.gd"

func _init():
	visibleName = "Nipple breasts"
	id = "breastsnipple"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersBreastExpansion/Bodyparts/BaseBDCC/BreastNipples/BreastNippleFlat.tscn"
	return "res://Modules/WintersBreastExpansion/Bodyparts/BaseBDCC/BreastNipples/BreastNipple.tscn"

func getCharacterCreatorDesc():
	return "WintersBreastExpansion"
