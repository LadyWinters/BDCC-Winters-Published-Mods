extends "res://Modules/WintersCoreModule/BodypartTemplates/TemplateBreastsScaleable.gd"

func _init():
	visibleName = "Inverted puffy breasts"
	id = "scaledbreastspuffyinv"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersBreastExpansion/Bodyparts/ScalyBodyparts/ScaledBreastPuffyInverted/ScaledBreastPuffyInvertedFlat.tscn"
	return "res://Modules/WintersBreastExpansion/Bodyparts/ScalyBodyparts/ScaledBreastPuffyInverted/ScaledBreastPuffyInverted.tscn"

func getCharacterCreatorDesc():
	return "WintersFluffyBodyparts"
