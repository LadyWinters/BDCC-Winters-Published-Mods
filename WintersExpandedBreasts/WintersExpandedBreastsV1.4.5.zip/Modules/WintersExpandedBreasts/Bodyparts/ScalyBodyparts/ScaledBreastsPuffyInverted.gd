extends "res://Modules/WintersCoreModule/BodypartTemplates/TemplateScripts/TemplateBreastsScaleable.gd"

func _init():
	visibleName = "Scaled inverted puffy breasts"
	id = "scaledbreastspuffyinv"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersExpandedBreasts/Bodyparts/ScalyBodyparts/ScaledBreastPuffyInverted/ScaledBreastPuffyInvertedFlat.tscn"
	return "res://Modules/WintersExpandedBreasts/Bodyparts/ScalyBodyparts/ScaledBreastPuffyInverted/ScaledBreastPuffyInverted.tscn"

func getCharacterCreatorDesc():
	return "WintersExpandedBreasts"
