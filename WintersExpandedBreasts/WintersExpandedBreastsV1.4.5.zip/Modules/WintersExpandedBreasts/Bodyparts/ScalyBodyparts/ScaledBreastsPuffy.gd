extends "res://Modules/WintersCoreModule/BodypartTemplates/TemplateScripts/TemplateBreastsScaleable.gd"

func _init():
	visibleName = "Scaled puffy breasts"
	id = "scaledbreastspuffy"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersExpandedBreasts/Bodyparts/ScalyBodyparts/ScaledBreastPuffy/ScaledBreastPuffyFlat.tscn"
	return "res://Modules/WintersExpandedBreasts/Bodyparts/ScalyBodyparts/ScaledBreastPuffy/ScaledBreastPuffy.tscn"

func getCharacterCreatorDesc():
	return "WintersExpandedBreasts"
