extends "res://Modules/WintersCoreModule/BodypartTemplates/TemplateScripts/TemplateBreastsScaleable.gd"

func _init():
	visibleName = "Fluffy puffy breasts"
	id = "fluffbreastspuffy"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersExpandedBreasts/Bodyparts/FluffyBodyparts/FluffyBreastsPuffy/FluffyBreastsPuffyFlat.tscn"
	return "res://Modules/WintersExpandedBreasts/Bodyparts/FluffyBodyparts/FluffyBreastsPuffy/FluffyBreastsPuffy.tscn"

func getCharacterCreatorDesc():
	return "WintersExpandedBreasts"
