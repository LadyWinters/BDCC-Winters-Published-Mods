extends "res://Modules/WintersCoreModule/BodypartTemplates/TemplateScripts/TemplateBreastsScaleable.gd"

func _init():
	visibleName = "Fluffy inverted nipple breasts"
	id = "fluffbreastsnippleinv"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersExpandedBreasts/Bodyparts/FluffyBodyparts/FluffyBreastsNipplesInverted/FluffyBreastsNipplesInvertedFlat.tscn"
	return "res://Modules/WintersExpandedBreasts/Bodyparts/FluffyBodyparts/FluffyBreastsNipplesInverted/FluffyBreastsNipplesInverted.tscn"

func getCharacterCreatorDesc():
	return "WintersExpandedBreasts"
