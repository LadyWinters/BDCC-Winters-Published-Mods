extends "res://Modules/WintersCoreModule/BodypartTemplates/TemplateScripts/TemplateBreastsScaleable.gd"

func _init():
	visibleName = "Fluffy nipple breasts"
	id = "fluffbreastsnipple"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersExpandedBreasts/Bodyparts/FluffyBodyparts/FluffyBreastsNipples/FluffyBreastsNippleFlat.tscn"
	return "res://Modules/WintersExpandedBreasts/Bodyparts/FluffyBodyparts/FluffyBreastsNipples/FluffyBreastsNipple.tscn"

func getCharacterCreatorDesc():
	return "WintersExpandedBreasts"
