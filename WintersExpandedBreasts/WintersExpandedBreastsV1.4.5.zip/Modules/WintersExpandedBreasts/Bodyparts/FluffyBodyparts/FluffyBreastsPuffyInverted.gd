extends "res://Modules/WintersCoreModule/BodypartTemplates/TemplateScripts/TemplateBreastsScaleable.gd"

func _init():
	visibleName = "Fluffy inverted puffy breasts"
	id = "fluffbreastspuffyinv"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersExpandedBreasts/Bodyparts/FluffyBodyparts/FluffyBreastsPuffyInverted/FluffyBreastsPuffyInvertedFlat.tscn"
	return "res://Modules/WintersExpandedBreasts/Bodyparts/FluffyBodyparts/FluffyBreastsPuffyInverted/FluffyBreastsPuffyInverted.tscn"

func getCharacterCreatorDesc():
	return "WintersExpandedBreasts"
