extends "res://Modules/WintersCoreModule/BodypartTemplates/TemplateScripts/TemplateBreastsScaleable.gd"

func _init():
	visibleName = "Inverted puffy breasts"
	id = "breastspuffyinv"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersExpandedBreasts/Bodyparts/BaseBDCC/BreastPuffyInverted/BreastPuffyInvertedFlat.tscn"
	return "res://Modules/WintersExpandedBreasts/Bodyparts/BaseBDCC/BreastPuffyInverted/BreastPuffyInverted.tscn"

func getCharacterCreatorDesc():
	return "WintersExpandedBreasts"
