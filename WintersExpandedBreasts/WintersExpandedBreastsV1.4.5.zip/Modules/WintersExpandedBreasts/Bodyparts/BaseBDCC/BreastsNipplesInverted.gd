extends "res://Modules/WintersCoreModule/BodypartTemplates/TemplateScripts/TemplateBreastsScaleable.gd"

func _init():
	visibleName = "Inverted nipple breasts"
	id = "breastsnippleinv"
	size = BreastsSize.C

func getDoll3DScene():
	var thesize = getSize()
	if(thesize <= BreastsSize.FLAT):
		return "res://Modules/WintersExpandedBreasts/Bodyparts/BaseBDCC/BreastNippleInverted/BreastNippleInvertedFlat.tscn"
	return "res://Modules/WintersExpandedBreasts/Bodyparts/BaseBDCC/BreastNippleInverted/BreastNippleInverted.tscn"

func getCharacterCreatorDesc():
	return "WintersExpandedBreasts"
