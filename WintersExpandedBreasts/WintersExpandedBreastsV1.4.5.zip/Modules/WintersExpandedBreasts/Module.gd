extends Module

var breastOptions : Dictionary = {
	# breastid: rat option
}

func _init():
	id = "WintersExpandedBreasts"
	author = "Avery Winters & Selinoccino (Assets by Anon)"

	bodyparts = GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedBreasts/Bodyparts/BaseBDCC/")

func register(): # best to do it here
	.register() # call our parent script's one first

	var modules = GlobalRegistry.getModules().keys() # to avoid calling too many times, and also only getting the keys for performance reasons kinda

	#Bodyparts
	if ("WintersFluffyBodyparts" in modules):
		for bp in GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedBreasts/Bodyparts/FluffyBodyparts/"):
			GlobalRegistry.registerBodypart(bp)
		for bp in GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedBreasts/Bodyparts/ScalyBodyparts/"):
			GlobalRegistry.registerBodypart(bp)

func isBreastEnabled(bid:String) -> bool:
	var option = breastOptions.get(bid)
	if option:
		return option.getValue()
	
	return getDefaultForBreast(bid)

func getDefaultForBreast(bid:String) -> bool:
	var bpo = GlobalRegistry.getBodypartRef(bid)
	if !bpo:
		return false
	return bpo.isWinteredDefault() if bpo.has_method("isWinteredDefault") else false

func RatConfigure(ratconf):
	ratconf.overrideModConfigName(id, "Winter's Expanded Breasts")
	
	for thing in ["Vanilla", "Fluffy", "Scaled"]:
		for t in [" (Feminine)", " (Masculine)"]:
			ratconf.addCategory(id, thing+t)
	
	var all = GlobalRegistry.getBodypartsIdsBySlot(BodypartSlot.Breasts)
	for bid in all:
		var bp = GlobalRegistry.getBodypartRef(bid)
		if bp.has_method("isWinterable") && bp.isWinterable():
			var disp : String = bp.visibleName if bp else ("Error (%s)" % bid)
			disp[0] = disp[0].to_upper()
			var desc : String = "Created by: %s\n\nEnable or disable this dick" % (bp.author if bp && bp.author else "(unknown)")
			
			var cat : String = getCategoryName(bid, bp.getTraits())
			
			breastOptions[bid] = ratconf.addOptionBool(id, bid, cat, disp, desc, getDefaultForBreast(bid))
	

func getCategoryName(bid:String, traits) -> String:
	var v : String = "Vanilla"
	if bid.begins_with("fluff"):
	 v = "Fluffy"
	elif bid.begins_with("scaled"):
		v = "Scaled"
	
	if !(traits and traits.get(PartTrait.BreastsMale, false)):
		v += " (Feminine)"
	else:
		v += " (Masculine)"
	return v
