extends "res://Modules/WintersExpandedBreasts/CompatabilityPatches/Hypertus/FluffyBreastsNipplesInvertedHyper.gd"

func _init():
	visibleName = "hyperable male fluffy inverted nipple breasts"
	id = "malefluffbreastsnippleinvhyperable"
	size = BreastsSize.FLAT

func getTraits():
	return {
		PartTrait.BreastsMale: true,
		"Hyperable": true,
	}

func getLewdAdjective():
	return RNG.pick(["firm", "strong"])

func getLewdName():
	if(size <= BreastsSize.A):
		return "pecs"

	return RNG.pick(["manbreasts", "manboobs", "mantits", "jugs", "orbs"])

func safeWhenExposed():
	if(size <= BreastsSize.A):
		return true
	
	return false

func generateDataFor(_dynamicCharacter):
	pass

func getVulgarName() -> String:
	return "male pecs"

func getAVulgarName() -> String:
	return getVulgarName()
