extends BodypartHead

func _init():
	visibleName = "horse head 5"
	id = "horsehead5"

func getCompatibleSpecies():
	return [Species.Equine]

func getDoll3DScene():
	return "res://Modules/WintersExpandedBaseSpecies/Bodyparts/SpeciesEquine/HorseHead5/HorseHead5.tscn"

func getHeadLength():
	return 0.55

func npcGenerationWeight(_dynamicCharacter):
	return 1.0

func getCharacterCreatorDesc():
	return "WintersExpandedBaseSpecies"
