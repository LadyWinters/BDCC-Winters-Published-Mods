extends Module

func _init():
	id = "WintersExpandedBaseSpecies"
	author = "Avery Winters & Selinoccino (Assets by Anon)"
	#Credits: Based on assembled mods by Anon compiled into one.
	
	bodyparts = GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedBaseSpecies/Bodyparts/")
