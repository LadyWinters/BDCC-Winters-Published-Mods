extends BodypartEars

func _init():
	visibleName = "Jackal ears (injured)"
	id = "jackalears2"

func getCompatibleSpecies():
	return [Species.Canine]

func getDoll3DScene():
	return "res://Modules/WintersExpandedBaseSpecies/Bodyparts/SpeciesCanine/JackalEars2/JackalEars2.tscn"

func getCharacterCreatorDesc():
	return "WintersExpandedBaseSpecies"
