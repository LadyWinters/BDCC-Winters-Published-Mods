extends BodypartHead

func _init():
	visibleName = "sabertooth wolf head"
	id = "saberwolfhead"

func getCompatibleSpecies():
	return [Species.Canine]

func getDoll3DScene():
	return "res://Modules/WintersExpandedBaseSpecies/Bodyparts/SpeciesCanine/WolfSabertoothHead/WolfSabertoothHead.tscn"

func getHeadLength():
	return 0.6

func npcGenerationWeight(_dynamicCharacter):
	return 1.0

func getCharacterCreatorDesc():
	return "WintersExpandedBaseSpecies"
