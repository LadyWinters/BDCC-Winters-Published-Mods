extends BodypartHead

func _init():
	visibleName = "sabertooth cat head"
	id = "sabercathead"

func getCompatibleSpecies():
	return [Species.Feline]

func getDoll3DScene():
	return "res://Modules/WintersExpandedBaseSpecies/Bodyparts/SpeciesFeline/FelineSabertooth/FelineSabertooth.tscn"

func getHeadLength():
	return 0.25

func npcGenerationWeight(_dynamicCharacter):
	return 1.0

func getCharacterCreatorDesc():
	return "WintersExpandedBaseSpecies"
