extends BodypartHead

func _init():
	visibleName = "dragon head 2"
	id = "dragonhead2"

func getCompatibleSpecies():
	return [Species.Dragon]

func getDoll3DScene():
	return "res://Modules/WintersExpandedBaseSpecies/Bodyparts/SpeciesDragon/DragonHead2/DragonHead2.tscn"

func getHeadLength():
	return 0.7

func npcGenerationWeight(_dynamicCharacter):
	return 1.0

func getCharacterCreatorDesc():
	return "WintersExpandedBaseSpecies"
