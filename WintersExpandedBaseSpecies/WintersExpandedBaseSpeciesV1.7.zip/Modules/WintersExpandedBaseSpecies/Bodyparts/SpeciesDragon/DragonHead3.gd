extends BodypartHead

func _init():
	visibleName = "dragon head 3"
	id = "dragonhead3"

func getCompatibleSpecies():
	return [Species.Dragon]

func getDoll3DScene():
	return "res://Modules/WintersExpandedBaseSpecies/Bodyparts/SpeciesDragon/DragonHead3/DragonHead3.tscn"

func getHeadLength():
	return 0.7

func npcGenerationWeight(_dynamicCharacter):
	return 1.0

func getCharacterCreatorDesc():
	return "WintersExpandedBaseSpecies"
