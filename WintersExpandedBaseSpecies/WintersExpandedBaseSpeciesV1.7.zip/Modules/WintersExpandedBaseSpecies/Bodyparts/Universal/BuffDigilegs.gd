extends BodypartLeg

func _init():
	visibleName = "buff digi legs"
	id = "buffdigilegs"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersExpandedBaseSpecies/Bodyparts/Universal/BuffDigileg/BuffDigilegs.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
