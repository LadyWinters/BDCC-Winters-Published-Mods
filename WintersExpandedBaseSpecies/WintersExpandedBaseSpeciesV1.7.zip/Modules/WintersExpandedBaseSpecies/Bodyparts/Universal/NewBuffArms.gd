extends "res://Player/Bodyparts/Arms/BuffArms.gd"


func getDoll3DScene():
	return "res://Modules/WintersExpandedBaseSpecies/Bodyparts/Universal/BuffArms/NewBuffArms.tscn"
