extends "res://Player/Bodyparts/Body/AnthroBody.gd"

func getDoll3DScene():
	return "res://Modules/WintersExpandedBaseSpecies/Bodyparts/Universal/Body/Thinbody.tscn"
