extends BodypartLeg

func _init():
	visibleName = "buff planti legs"
	id = "buffplantilegs"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersExpandedBaseSpecies/Bodyparts/Universal/BuffPlantilegs/BuffPlantilegs.tscn"

func getTraits():
	return {
		PartTrait.LegsPlanti: true,
	}
