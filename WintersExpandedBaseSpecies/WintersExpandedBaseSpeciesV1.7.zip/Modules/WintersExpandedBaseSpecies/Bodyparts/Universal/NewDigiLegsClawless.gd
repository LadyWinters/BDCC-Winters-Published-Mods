extends BodypartLeg

func _init():
	visibleName = "digi legs clawless"
	id = "digilegsclawless"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersExpandedBaseSpecies/Bodyparts/Universal/DigilegClawless/NewDiglegsClawless.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
