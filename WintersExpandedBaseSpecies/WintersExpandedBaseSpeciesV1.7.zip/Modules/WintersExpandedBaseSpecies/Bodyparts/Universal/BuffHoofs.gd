extends BodypartLeg

func _init():
	visibleName = "buff hoofs"
	id = "buffhoofs"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersExpandedBaseSpecies/Bodyparts/Universal/BuffHoofs/BuffHoofs.tscn"

func getTraits():
	return {
		PartTrait.LegsHoofs: true,
	}
