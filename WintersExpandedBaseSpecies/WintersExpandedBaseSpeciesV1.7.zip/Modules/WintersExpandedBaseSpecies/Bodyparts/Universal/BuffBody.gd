extends BodypartBody

func _init():
	visibleName = "buff body"
	id = "buffbody"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersExpandedBaseSpecies/Bodyparts/Universal/BuffBody/BuffBody.tscn"

func getVulgarName() -> String:
	return "normal buff body"

func getAVulgarName() -> String:
	return "a normal buff body"
