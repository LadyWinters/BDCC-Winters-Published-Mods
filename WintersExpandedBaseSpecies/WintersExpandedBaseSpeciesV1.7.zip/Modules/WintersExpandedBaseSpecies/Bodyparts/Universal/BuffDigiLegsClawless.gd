extends BodypartLeg

func _init():
	visibleName = "buff digi legs clawless"
	id = "buffdigilegsclawless"

func getCompatibleSpecies():
	return [Species.Any]

func getDoll3DScene():
	return "res://Modules/WintersExpandedBaseSpecies/Bodyparts/Universal/BuffDigilegClawless/BuffDigilegsClawless.tscn"

func getTraits():
	return {
		PartTrait.LegsDigi: true,
	}
