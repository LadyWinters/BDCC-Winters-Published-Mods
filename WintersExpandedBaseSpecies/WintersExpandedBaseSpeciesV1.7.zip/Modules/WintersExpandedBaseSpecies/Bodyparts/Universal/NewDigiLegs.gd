extends "res://Player/Bodyparts/Legs/DigiLegs.gd"

func getDoll3DScene():
	return "res://Modules/WintersExpandedBaseSpecies/Bodyparts/Universal/Digileg/NewDiglegs.tscn"
