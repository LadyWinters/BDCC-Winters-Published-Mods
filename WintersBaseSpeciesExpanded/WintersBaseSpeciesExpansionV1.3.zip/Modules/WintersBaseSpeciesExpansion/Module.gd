extends Module

func _init():
	id = "WintersBaseSpeciesExpansion"
	author = "Avery Winters"
	#Credits: Based on assembled mods by Anon compiled into one. Winter Eira helped with the original merging.
	
	bodyparts = [
		#Canine
		"res://Modules/WintersBaseSpeciesExpansion/SpeciesCanine/Bodyparts/CanineSabertooth.gd",
		"res://Modules/WintersBaseSpeciesExpansion/SpeciesCanine/Bodyparts/HyenaEars.gd",
		"res://Modules/WintersBaseSpeciesExpansion/SpeciesCanine/Bodyparts/HyenaTail.gd",
		"res://Modules/WintersBaseSpeciesExpansion/SpeciesCanine/Bodyparts/HyenaHead.gd",
		"res://Modules/WintersBaseSpeciesExpansion/SpeciesCanine/Bodyparts/JackalEars1.gd",
		"res://Modules/WintersBaseSpeciesExpansion/SpeciesCanine/Bodyparts/JackalEars2.gd",
		"res://Modules/WintersBaseSpeciesExpansion/SpeciesCanine/Bodyparts/JackalTail.gd",
		#Dragon
		"res://Modules/WintersBaseSpeciesExpansion/SpeciesDragon/Bodyparts/DragonHead2.gd",
		"res://Modules/WintersBaseSpeciesExpansion/SpeciesDragon/Bodyparts/DragonHead3.gd",
		"res://Modules/WintersBaseSpeciesExpansion/SpeciesDragon/Bodyparts/DragonHorns4.gd",
		"res://Modules/WintersBaseSpeciesExpansion/SpeciesDragon/Bodyparts/DragonHorns5.gd",
		"res://Modules/WintersBaseSpeciesExpansion/SpeciesDragon/Bodyparts/DragonTail2.gd",
		#Equine
		"res://Modules/WintersBaseSpeciesExpansion/SpeciesEquine/Bodyparts/HorseHead3.gd",
		"res://Modules/WintersBaseSpeciesExpansion/SpeciesEquine/Bodyparts/HorseHead4.gd",
		"res://Modules/WintersBaseSpeciesExpansion/SpeciesEquine/Bodyparts/HorseHead5.gd",
		#Feline
		"res://Modules/WintersBaseSpeciesExpansion/SpeciesFeline/Bodyparts/FelineSabertooth.gd",
		#Universal
		"res://Modules/WintersBaseSpeciesExpansion/Universal/Earless.gd",
		]
