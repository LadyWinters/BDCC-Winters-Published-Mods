extends BodypartEars

func _init():
	visibleName = "rabbit ears 1"
	id = "rabbitears1"

func getCompatibleSpecies():
	return ["rabbit"]

func getDoll3DScene():
	return "res://Modules/WintersExpandedCritters/Bodyparts/Herbivore/Rabbit/RabbitEars1/RabbitEars1.tscn"
