extends BodypartEars

func _init():
	visibleName = "rabbit ears 3"
	id = "rabbitears3"

func getCompatibleSpecies():
	return ["rabbit"]

func getDoll3DScene():
	return "res://Modules/WintersExpandedCritters/Bodyparts/Herbivore/Rabbit/RabbitEars3/RabbitEars3.tscn"
