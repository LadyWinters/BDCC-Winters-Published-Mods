extends Module

var RAT_ArchetypeLoad = ResourceLoader.exists("res://Modules/RATBodypartArchetypes/Module.gd")

func _init():
	id = "WintersExpandedCritters"
	author = "Avery Winters & Selinoccino"

	species = GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedCritters/Species/")
	
	bodyparts = GlobalRegistry.getScriptsInFoldersRecursive("res://Modules/WintersExpandedCritters/Bodyparts/")

func getAddedRatArchetypes() -> Dictionary:
	var pathDir = "res://Modules/WintersCoreModule/CompatabilityPatches/RAT_BodypartArchetypes/"

	return {
	# species id: [array of paths to file] or "path to file"
	# turns to speciesID: types dictionary (typeID: type dict)

	#Demonic Species Archetypes
	"hellhound": [pathDir+"DemonicArchetypes.json"],
	"hellkitty": [pathDir+"DemonicArchetypes.json"],
	"hellpony": [pathDir+"DemonicArchetypes.json"],
	
	#Herbivore Species Archetypes
	"rabbit": [pathDir+"ClawlessArchetypes.json"],
	
	}
