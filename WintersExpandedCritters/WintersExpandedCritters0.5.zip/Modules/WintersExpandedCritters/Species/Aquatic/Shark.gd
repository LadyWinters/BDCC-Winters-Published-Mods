extends Species

func _init():
	id = "shark"
	
func getVisibleName():
	return "Shark"

func getDefaultLegs(_gender):
	return "sharklegs"

func getDefaultTail(_gender):
	return "sharktail"

func isPlayable():
	return true

func getVisibleDescription():
	return "f i s h"

func getDefaultHead(_gender):
	return "sharkhead"

func getDefaultArms(_gender):
	return "sharkarms"

func getDefaultEars(_gender):
	return "sharkears"

func getDefaultBody(_gender):
	return "sharkbody"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("WintersTaperedPenises" in GlobalRegistry.getModules()):
			return "taperedpenisslit"
		else:
			return "dragonpenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[2, 3.0],
		[3, 6.0],
		[4, 8.0],
		[5, 6.0],
		[6, 4.0],
		[7, 1.0],
	]
	
#func getAllowedBodyparts():
#	return ["dragonpenis"]

