extends Species

func _init():
	id = "seahorse"
	
func getVisibleName():
	return "Seahorse"

func getDefaultLegs(_gender):
	return "sealegs"

func getDefaultTail(_gender):
	return "seatail2"

func isPlayable():
	return true

func getVisibleDescription():
	return "Horse Fish. Supposedly the genetic origin of the 'anus wombs' that cis men over the known universe dread. or dream of. Remember to be tested!"

func getDefaultHead(_gender):
	return "seahorsehead"

func getDefaultArms(_gender):
	return "seaarms"

func getDefaultEars(_gender):
	return "seaears"

func getDefaultAnus(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "anuswomb"
	else:
		return "anus"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("WintersTaperedPenises" in GlobalRegistry.getModules()):
			return "taperedpenisslit"
		else:
			return "dragonpenis"
	else:
		return null

func getDefaultHorns(_gender):
	return "seahorsecrest1"

func getDefaultBody(_gender):
	return "sharkbody"

func getEggCellOvulationAmount():
	return [
		[1, 1.0],
		[2, 5.0],
		[3, 1.0],
		[4, 0.5],
	]

#func onDynamicNpcCreation(_npc, _args):
#	_npc.giveBodypartUnlessSame(GlobalRegistry.createBodypart("baldhair"))

func getAllowedBodyparts():
	return ["sharkbody", "dragonears", "dragonears2", "dragonpenis", "dragonpenisbarb"]

func getSkinType():
	return SkinType.Scales
