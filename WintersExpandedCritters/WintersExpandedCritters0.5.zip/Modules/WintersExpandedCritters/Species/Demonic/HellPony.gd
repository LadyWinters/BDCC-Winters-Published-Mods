extends Species

var Bodyparts : Array = []
var maleBoobs : Array = [] 
var femaleBoobs : Array = []
var hasArchetype = ("RAT_FluffyArchetypes" in GlobalRegistry.getModules())
var hasFluff = ("WintersFluffyBodyparts" in GlobalRegistry.getModules())

func _init():
	id = "hellpony"

	# Get Allowed Bodyparts - Appends additional bodyparts into the allowed list depending on mod installs. Additional mod integration just requires additional if checks
	Bodyparts.append_array(["horsehead", "horseheadbig", "horseears"])
	if ("WintersExpandedBaseSpecies" in GlobalRegistry.getModules()):
		Bodyparts.append_array(["horsehead3", "horsehead4", "horsehead5"]) 
	if ("songjohorseparts" in GlobalRegistry.getModules()):
		Bodyparts.append_array(["songhorsehead", "sdeerantlers3"])

	# Get Default Breasts - Handles making the array of allowed breasts based on what mods are installed making a single array to be called later
	var hasBoob = ("WintersExpandedBreasts" in GlobalRegistry.getModules())

	if hasFluff && hasBoob: #FluffyBodyparts & ExpandedBreasts
		maleBoobs = ["fluffmalebreastsnipple", "fluffmalebreastsnippleinv", "fluffmalebreastspuffy", "fluffmalebreastspuffyinv"]
		femaleBoobs = ["fluffbreastsnipple", "fluffbreastsnippleinv", "fluffbreastspuffy", "fluffbreastspuffyinv"]
	elif hasBoob: #BreastExpanded Only
		maleBoobs = ["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv"]
		femaleBoobs = ["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv"]
	elif hasFluff: #FluffyBodyparts Only
		maleBoobs = ["fluffmalebreasts"]
		femaleBoobs = ["fluffbreasts"]
	else: #Vanilla Breasts
		maleBoobs = ["malebreasts"]
		femaleBoobs = ["humanbreasts"]

func getVisibleName():
	return "Hellpony"

func getDefaultTail(_gender):
	return "demontail"

func getDefaultHorns(_gender):
	return "demonhorns"

func isPlayable():
	return true

func getVisibleDescription():
	return "Your demonic hoofy neighbors"

func getDefaultHead(_gender):
	return "horsehead"

func getDefaultEars(_gender):
	return "horseears"

func getDefaultBody(_gender):
	if (hasFluff && !hasArchetype):
		return "bufffluffbody"
	return "anthrobody"

# Default Fluffy / Scruffy Parts - We use the variables above to confirm that fluffybodyparts is installed but Rat_Archetypes is not make species fluffy
func getDefaultLegs(_gender):
	if (hasFluff && !hasArchetype):
		return "bufffluffhoofs"
	return "hoofs"

func getDefaultArms(_gender):
	if (hasFluff && !hasArchetype):
		return "bufffluffarms"
	return "anthroarms"

func getDefaultBreasts(_gender):
	if(_gender in [Gender.Male]):
		return RNG.pick(maleBoobs)
	return RNG.pick(femaleBoobs)

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("WintersExpandedPenises" in GlobalRegistry.getModules()):
			return RNG.pick(["equinepenis", "equinepenisbarbknot", "equinepenisbarb", "equinepenisknot", "equinepenistapered"])
		return "equinepenis"
	else:
		return null

func getEggCellOvulationAmount():
	return [
		[2, 6.0],
		[3, 9.0],
		[4, 12.0],
		[5, 9.0],
		[6, 7.0],
		[7, 4.0],
	]

func npcGenerationWeight():
	return 0.5

func getSkinType():
	return SkinType.Fur

func getAllowedBodyparts():
	return Bodyparts
