extends "res://Species/Demon.gd"

var maleBoobs = [] 
var femaleBoobs = []

var hasPenis = ("WintersExpandedPenises" in GlobalRegistry.getModules())

var mascIndexes : Array = []
var femIndexes : Array = []

func repopBoobs() -> void:
	femIndexes.clear()
	mascIndexes.clear()
	var mod : Module = GlobalRegistry.getModule("WintersExpandedBreasts")
	for i in maleBoobs.size():
		if mod.isBreastEnabled(maleBoobs[i]):
			mascIndexes.append(i)
	for i in femaleBoobs.size():
		if mod.isBreastEnabled(femaleBoobs[i]):
			femIndexes.append(i)

func _init():
	# Get Default Breasts - Handles making the array of allowed breasts based on what mods are installed making a single array to be called later
	var hasBoob = ("WintersExpandedBreasts" in GlobalRegistry.getModules())
	
	if ("RodentUtils" in GlobalRegistry.getModules()):
		GlobalRegistry.getModule("RodentUtils").connect("configClosed", self, "repopBoobs")

	if hasBoob: #ExpandedBreasts Only
		maleBoobs = ["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv"]
		femaleBoobs = ["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv"]
	else: #Vanilla Breasts
		maleBoobs = ["malebreasts"]
		femaleBoobs = ["humanbreasts"]
	
	repopBoobs()

func getDefaultLegs(_gender):
	return "hoofs"

func getDefaultTail(_gender):
	return "demontail"

func getDefaultHorns(_gender):
	return "demonhorns"

func getDefaultHead(_gender):
	return "humanhead"

func getDefaultArms(_gender):
	return "anthroarms"

func getDefaultEars(_gender):
	return "humanears"

func getDefaultBreasts(_gender):
	if(_gender in [Gender.Male]):
		return maleBoobs[RNG.pick(mascIndexes)] if mascIndexes else null
	return femaleBoobs[RNG.pick(femIndexes)] if femIndexes else null

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if (hasPenis):
			return RNG.pick(["equinepenis", "equinepenisbarbknot", "equinepenisbarb", "equinepenisknot", "equinepenistapered"])
		return "equinepenis"
	else:
		return null

func npcGenerationWeight():
	return 0.0
