extends Reference

var id : String = "WintersCoreModule" # needed for sorting

var maleBoobs : Array = [] 
var femaleBoobs : Array = []
var hasArchetype = ("RAT_FluffyArchetypes" in GlobalRegistry.getModules())
var hasFluff = ("WintersFluffyBodyparts" in GlobalRegistry.getModules())
var hasPenis = ("WintersExpandedPenises" in GlobalRegistry.getModules())

var mascIndexes : Array = []
var femIndexes : Array = []

func repopBoobs() -> void:
	femIndexes.clear()
	mascIndexes.clear()
	var mod : Module = GlobalRegistry.getModule("WintersExpandedBreasts")
	for i in maleBoobs.size():
		if mod.isBreastEnabled(maleBoobs[i]):
			mascIndexes.append(i)
	for i in femaleBoobs.size():
		if mod.isBreastEnabled(femaleBoobs[i]):
			femIndexes.append(i)

func _init() -> void:
	if ("RodentUtils" in GlobalRegistry.getModules()):
		GlobalRegistry.getModule("RodentUtils").connect("configClosed", self, "repopBoobs")
	

func getDefaultBreasts(_old, _gender):
	if(_gender in [Gender.Male]):
		return maleBoobs[RNG.pick(mascIndexes)] if mascIndexes else _old
	return femaleBoobs[RNG.pick(femIndexes)] if femIndexes else _old

func getRegisteredMethods() -> Array:
	return []

func registerToSpecies(sp:Species) -> void:
	repopBoobs()
	for method in getRegisteredMethods():
		var cb = sp.createCallable(self, method)
		sp.addCallableToMethod(cb, method)
