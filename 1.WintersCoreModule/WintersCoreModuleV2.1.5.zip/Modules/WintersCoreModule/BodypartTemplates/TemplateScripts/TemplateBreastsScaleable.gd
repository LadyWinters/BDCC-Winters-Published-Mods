extends BodypartBreasts

func getTraits():
	return {
		PartTrait.BreastsFemale: true,
	}

func getCompatibleSpecies():
	return [Species.Any] if GlobalRegistry.getModule("WintersExpandedBreasts").isBreastEnabled(id) else []

func getBreastsScale():
	var thesize = getSize()
	return BreastsSize.breastSizeToBoneScale(thesize)

func generateDataFor(_dynamicCharacter):
	size = RNG.pick([
		BreastsSize.A, BreastsSize.B, BreastsSize.C, BreastsSize.D, BreastsSize.DD, BreastsSize.DDD,
	])

func getVulgarName() -> String:
	return "female breasts"

func getAVulgarName() -> String:
	return getVulgarName()

func isWinterable() -> bool:
	return true

func isWinteredDefault() -> bool:
	return true
