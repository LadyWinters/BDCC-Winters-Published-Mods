extends "res://Modules/WintersCoreModule/CompatibilityPatches/RAT_Archetypes/SpeciesBase.gd"

func getRegisteredMethods() -> Array:
	var a : Array = []
	for suffix in [
		"Ears", "Legs", "Breasts"
	]:
		a.append("getDefault"+suffix)
	
	return a

func _init():
	# Get Default Breasts - Handles making the array of allowed breasts based on what mods are installed making a single array to be called later
	var hasBoob = ("WintersExpandedBreasts" in GlobalRegistry.getModules())

	if hasBoob: #ExpandedBreasts Only
		maleBoobs = ["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv"]
		femaleBoobs = ["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv"]
	else: #Vanilla Breasts
		maleBoobs = ["malebreasts"]
		femaleBoobs = ["humanbreasts"]

func getDefaultLegs(_old, _gender):
	return "plantilegs"

func getDefaultEars(_old, _gender):
	return "humanears"
