extends "res://Species/Dragon.gd"

var maleBoobs : Array = [] 
var femaleBoobs : Array = []
var hasFluff = ("WintersFluffyBodyparts" in GlobalRegistry.getModules())
var hasPenis = ("WintersExpandedPenises" in GlobalRegistry.getModules())

var mascIndexes : Array = []
var femIndexes : Array = []

func repopBoobs() -> void:
	femIndexes.clear()
	mascIndexes.clear()
	var mod : Module = GlobalRegistry.getModules().get("WintersExpandedBreasts")
	if !mod:
		return
	for i in maleBoobs.size():
		if mod.isBreastEnabled(maleBoobs[i]):
			mascIndexes.append(i)
	for i in femaleBoobs.size():
		if mod.isBreastEnabled(femaleBoobs[i]):
			femIndexes.append(i)

func _init():
	# Get Default Breasts - Handles making the array of allowed breasts based on what mods are installed making a single array to be called later
	var hasBoob = ("WintersExpandedBreasts" in GlobalRegistry.getModules())
	
	if ("RodentUtils" in GlobalRegistry.getModules()):
		GlobalRegistry.getModule("RodentUtils").connect("configClosed", self, "repopBoobs")

	if hasFluff && hasBoob: #FluffyBodyparts & ExpandedBreasts
		maleBoobs = ["scaledmalebreastsnipple", "scaledmalebreastsnippleinv", "scaledmalebreastspuffy", "scaledmalebreastspuffyinv"]
		femaleBoobs = ["scaledbreastsnipple", "scaledbreastsnippleinv", "scaledbreastspuffy", "scaledbreastspuffyinv"]
	elif hasBoob: #ExpandedBreasts Only
		maleBoobs = ["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv"]
		femaleBoobs = ["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv"]
	elif hasFluff: #FluffyBodyparts Only
		maleBoobs = ["fluffmalebreasts"]
		femaleBoobs = ["fluffbreasts"]
	else: #Vanilla Breasts
		maleBoobs = ["malebreasts"]
		femaleBoobs = ["humanbreasts"]
	
	repopBoobs()

func getDefaultTail(_gender):
	return "dragontail"

func getDefaultHorns(_gender):
	return "dragonhorns"

func getDefaultHead(_gender):
	return "dragonhead"

func getDefaultEars(_gender):
	return "dragonears"

func getDefaultBody(_gender):
	if (hasFluff):
		return "scaledbody"
	return "anthrobody"


func getDefaultLegs(_gender):
	if (hasFluff):
		return "scaledlegs"
	return "digilegs"

func getDefaultArms(_gender):
	if (hasFluff):
		return "scaledarms"
	return "anthroarms"

func getDefaultBreasts(_gender):
	if(_gender in [Gender.Male]):
		return maleBoobs[RNG.pick(mascIndexes)] if mascIndexes else null
	return femaleBoobs[RNG.pick(femIndexes)] if femIndexes else null

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if (hasPenis):
			return RNG.pick(["dragonpenis", "DPB1", "DPB2", "DPB3"])
		return "dragonpenis"
	else:
		return null

func getDefaultVagina(_gender):
	if(_gender in [Gender.Female, Gender.Androgynous]):
		return "vaginaEggs"
	else:
		return null
