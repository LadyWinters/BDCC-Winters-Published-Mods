extends "res://Species/Feline.gd"

var maleBoobs : Array = [] 
var femaleBoobs : Array = []
var hasArchetype = ("RAT_FluffyArchetypes" in GlobalRegistry.getModules())
var hasFluff = ("WintersFluffyBodyparts" in GlobalRegistry.getModules())

func _init():
	# Get Default Breasts - Handles making the array of allowed breasts based on what mods are installed making a single array to be called later
	var hasBoob = ("WintersExpandedBreasts" in GlobalRegistry.getModules())

	if hasFluff && hasBoob: #FluffyBodyparts & ExpandedBreasts
		maleBoobs = ["fluffmalebreastsnipple", "fluffmalebreastsnippleinv", "fluffmalebreastspuffy", "fluffmalebreastspuffyinv"]
		femaleBoobs = ["fluffbreastsnipple", "fluffbreastsnippleinv", "fluffbreastspuffy", "fluffbreastspuffyinv"]
	elif hasBoob: #ExpandedBreasts Only
		maleBoobs = ["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv"]
		femaleBoobs = ["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv"]
	elif hasFluff: #FluffyBodyparts Only
		maleBoobs = ["fluffmalebreasts"]
		femaleBoobs = ["fluffbreasts"]
	else: #Vanilla Breasts
		maleBoobs = ["malebreasts"]
		femaleBoobs = ["humanbreasts"]

func getDefaultTail(_gender):
	return "felinetail"

func getDefaultHead(_gender):
	return "felinehead"

func getDefaultEars(_gender):
	return "felineears"

func getDefaultBody(_gender):
	if (hasFluff && !hasArchetype):
		return "fluffbody"
	return "anthrobody"

func getDefaultLegs(_gender):
	if (hasFluff && !hasArchetype):
		return "flufflegsclawless"
	return "digilegs"

func getDefaultArms(_gender):
	if (hasFluff && !hasArchetype):
		return "fluffclawedarms"
	return "anthroarms"

func getDefaultBreasts(_gender):
	if(_gender in [Gender.Male]):
		return RNG.pick(maleBoobs)
	return RNG.pick(femaleBoobs)

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("WintersExpandedPenises" in GlobalRegistry.getModules()):
			return "barbedfluffypenis"
		else:
			return "felinepenis"
	else:
		return null
