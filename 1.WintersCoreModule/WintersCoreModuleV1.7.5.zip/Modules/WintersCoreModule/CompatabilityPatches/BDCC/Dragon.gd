extends "res://Species/Dragon.gd"

var maleBoobs : Array = [] 
var femaleBoobs : Array = []
var hasArchetype = ("RAT_FluffyArchetypes" in GlobalRegistry.getModules())
var hasFluff = ("WintersFluffyBodyparts" in GlobalRegistry.getModules())

func _init():
	# Get Default Breasts - Handles making the array of allowed breasts based on what mods are installed making a single array to be called later
	var hasBoob = ("WintersExpandedBreasts" in GlobalRegistry.getModules())

	if hasFluff && hasBoob: #FluffyBodyparts & ExpandedBreasts
		maleBoobs = ["scaledmalebreastsnipple", "scaledmalebreastsnippleinv", "scaledmalebreastspuffy", "scaledmalebreastspuffyinv"]
		femaleBoobs = ["scaledbreastsnipple", "scaledbreastsnippleinv", "scaledbreastspuffy", "scaledbreastspuffyinv"]
	elif hasBoob: #ExpandedBreasts Only
		maleBoobs = ["malebreastsnipple", "malebreastsnippleinv", "malebreastspuffy", "malebreastspuffyinv"]
		femaleBoobs = ["breastsnipple", "breastsnippleinv", "breastspuffy", "breastspuffyinv"]
	elif hasFluff: #FluffyBodyparts Only
		maleBoobs = ["fluffmalebreasts"]
		femaleBoobs = ["fluffbreasts"]
	else: #Vanilla Breasts
		maleBoobs = ["malebreasts"]
		femaleBoobs = ["humanbreasts"]

func getDefaultTail(_gender):
	return "dragontail"

func getDefaultHorns(_gender):
	return "dragonhorns"

func getDefaultHead(_gender):
	return "dragonhead"

func getDefaultEars(_gender):
	return "dragonears"

func getDefaultBody(_gender):
	if (hasFluff && !hasArchetype):
		return "scaledbody"
	return "anthrobody"


func getDefaultLegs(_gender):
	if (hasFluff && !hasArchetype):
		return "scaledlegs"
	return "digilegs"

func getDefaultArms(_gender):
	if (hasFluff && !hasArchetype):
		return "scaledarms"
	return "anthroarms"

func getDefaultBreasts(_gender):
	if(_gender in [Gender.Male]):
		return RNG.pick(maleBoobs)
	return RNG.pick(femaleBoobs)

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		if ("More Dragon Penis" in GlobalRegistry.getModules()):
			return RNG.pick(["dragonpenis", "DPB1", "DPB2", "DPB3"])
		return "dragonpenis"
	else:
		return null

func getDefaultVagina(_gender):
	if(_gender in [Gender.Female, Gender.Androgynous]):
		return "vaginaEggs"
	else:
		return null
