extends "res://Species/Feline.gd"

func getDefaultLegs(_gender):
	return "digilegs"

func getDefaultTail(_gender):
	return "felinetail"

func getDefaultHead(_gender):
	return "felinehead"

func getDefaultArms(_gender):
	return "anthroarms"

func getDefaultEars(_gender):
	return "felineears"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "felinepenis"
	else:
		return null
