extends "res://Species/Human.gd"

func getDefaultLegs(_gender):
	return "plantilegs"

func getDefaultEars(_gender):
	return "humanears"
