extends "res://Species/Dragon.gd"

func getDefaultLegs(_gender):
	return "digilegs"

func getDefaultTail(_gender):
	return "dragontail"

func getDefaultArms(_gender):
	return "anthroarms"

func getDefaultHorns(_gender):
	return "dragonhorns"

func getDefaultHead(_gender):
	return "dragonhead"

func getDefaultEars(_gender):
	return "dragonears"

func getDefaultPenis(_gender):
	if(_gender in [Gender.Male, Gender.Androgynous]):
		return "dragonpenis"
	else:
		return null
